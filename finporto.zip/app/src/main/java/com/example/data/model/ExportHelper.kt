package com.example.data.model

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import com.example.data.local.entity.TransactionEntity
import com.example.util.CurrencyUtils
import com.example.util.DateUtils
import java.io.File
import java.io.FileWriter

object ExportHelper {
    fun generateTransactionsCsv(transactions: List<TransactionEntity>): String {
        val sb = StringBuilder()
        sb.append("ID,Tanggal,Waktu,Tipe,Kategori,Nominal,Dompet Asal,Dompet Tujuan,Biaya Admin,Catatan\n")
        
        for (tx in transactions) {
            val dateStr = DateUtils.formatDate(tx.date)
            val timeStr = DateUtils.formatDateTime(tx.date)
            val cleanNote = tx.note.replace("\"", "\"\"")
            val cleanCat = tx.categoryName.replace("\"", "\"\"")
            val cleanWallet = tx.walletName.replace("\"", "\"\"")
            val cleanTargetWallet = (tx.targetWalletName ?: "").replace("\"", "\"\"")
            
            sb.append("${tx.id},\"$dateStr\",\"$timeStr\",${tx.type},\"$cleanCat\",${tx.amount},\"$cleanWallet\",\"$cleanTargetWallet\",${tx.adminFee},\"$cleanNote\"\n")
        }
        return sb.toString()
    }

    fun shareCsvFile(context: Context, csvContent: String, fileName: String = "laporan_transaksi_finporto.csv") {
        try {
            val cacheDir = File(context.cacheDir, "exports")
            if (!cacheDir.exists()) cacheDir.mkdirs()
            val file = File(cacheDir, fileName)
            val writer = FileWriter(file)
            writer.write(csvContent)
            writer.flush()
            writer.close()

            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.provider",
                file
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/csv"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "Laporan Keuangan FinPorto")
                putExtra(Intent.EXTRA_TEXT, "Berikut adalah ekspor data transaksi dari FinPorto.")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Bagikan Laporan CSV"))
        } catch (e: Exception) {
            // Fallback plain text sharing
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "Laporan Keuangan FinPorto (CSV)")
                putExtra(Intent.EXTRA_TEXT, csvContent)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Salin Data CSV"))
        }
    }
}
