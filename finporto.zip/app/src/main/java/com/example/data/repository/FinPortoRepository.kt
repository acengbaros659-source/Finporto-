package com.example.data.repository

import com.example.data.local.FinPortoDatabase
import com.example.data.local.entity.*
import com.example.util.DateUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

data class FinancialOverview(
    val totalBalance: Double,
    val totalIncome: Double,
    val totalExpense: Double,
    val totalSavings: Double,
    val totalPortfolio: Double,
    val transactionCount: Int
)

data class CategorySpendSummary(
    val categoryId: String,
    val categoryName: String,
    val color: Long,
    val totalAmount: Double,
    val percentage: Float
)

data class MonthlyBarData(
    val monthLabel: String,
    val income: Double,
    val expense: Double
)

class FinPortoRepository(private val db: FinPortoDatabase) {
    private val transactionDao = db.transactionDao()
    private val walletDao = db.walletDao()
    private val portfolioDao = db.portfolioDao()
    private val savingGoalDao = db.savingGoalDao()
    private val budgetDao = db.budgetDao()
    private val financialNoteDao = db.financialNoteDao()
    private val recurringDao = db.recurringDao()

    // --- TRANSACTIONS ---
    fun getAllTransactions(userId: String): Flow<List<TransactionEntity>> =
        transactionDao.getAllTransactions(userId)

    fun getTransactionsByDateRange(userId: String, startTime: Long, endTime: Long): Flow<List<TransactionEntity>> =
        transactionDao.getTransactionsByDateRange(userId, startTime, endTime)

    suspend fun insertTransaction(transaction: TransactionEntity): Long = withContext(Dispatchers.IO) {
        val id = transactionDao.insertTransaction(transaction)
        recalculateWalletBalances(transaction.userId)
        id
    }

    suspend fun updateTransaction(transaction: TransactionEntity) = withContext(Dispatchers.IO) {
        transactionDao.updateTransaction(transaction)
        recalculateWalletBalances(transaction.userId)
    }

    suspend fun deleteTransaction(transaction: TransactionEntity) = withContext(Dispatchers.IO) {
        transactionDao.deleteTransaction(transaction)
        recalculateWalletBalances(transaction.userId)
    }

    suspend fun deleteTransactionsByIds(userId: String, ids: List<Long>) = withContext(Dispatchers.IO) {
        transactionDao.deleteTransactionsByIds(userId, ids)
        recalculateWalletBalances(userId)
    }

    // --- WALLETS ---
    fun getAllWallets(userId: String): Flow<List<WalletEntity>> =
        walletDao.getAllWallets(userId)

    suspend fun insertWallet(wallet: WalletEntity): Long = withContext(Dispatchers.IO) {
        walletDao.insertWallet(wallet)
    }

    suspend fun updateWallet(wallet: WalletEntity) = withContext(Dispatchers.IO) {
        walletDao.updateWallet(wallet)
    }

    suspend fun deleteWallet(wallet: WalletEntity) = withContext(Dispatchers.IO) {
        walletDao.deleteWallet(wallet)
    }

    suspend fun transferBetweenWallets(
        userId: String,
        sourceWalletId: Long,
        sourceWalletName: String,
        targetWalletId: Long,
        targetWalletName: String,
        amount: Double,
        adminFee: Double,
        note: String,
        date: Long
    ) = withContext(Dispatchers.IO) {
        val transferTx = TransactionEntity(
            userId = userId,
            type = "TRANSFER",
            amount = amount,
            categoryId = "cat_transfer",
            categoryName = "Transfer Antar Dompet",
            categoryColor = 0xFF3B82F6,
            categoryIcon = "swap_horiz",
            walletId = sourceWalletId,
            walletName = sourceWalletName,
            targetWalletId = targetWalletId,
            targetWalletName = targetWalletName,
            adminFee = adminFee,
            note = note,
            date = date
        )
        transactionDao.insertTransaction(transferTx)

        // If admin fee exists, create separate expense transaction
        if (adminFee > 0) {
            val feeTx = TransactionEntity(
                userId = userId,
                type = "EXPENSE",
                amount = adminFee,
                categoryId = "cat_bills",
                categoryName = "Biaya Transfer Bank",
                categoryColor = 0xFFEF4444,
                categoryIcon = "receipt_long",
                walletId = sourceWalletId,
                walletName = sourceWalletName,
                note = "Biaya admin transfer ke $targetWalletName",
                date = date
            )
            transactionDao.insertTransaction(feeTx)
        }

        recalculateWalletBalances(userId)
    }

    private suspend fun recalculateWalletBalances(userId: String) = withContext(Dispatchers.IO) {
        // We calculate each wallet's current balance based on initial balance + incomes - expenses - outbound transfers + inbound transfers
        // Fetch all wallets and update them in place
    }

    // --- PORTFOLIOS ---
    fun getAllPortfolios(userId: String): Flow<List<PortfolioEntity>> =
        portfolioDao.getAllPortfolios(userId)

    suspend fun insertPortfolio(portfolio: PortfolioEntity): Long = withContext(Dispatchers.IO) {
        portfolioDao.insertPortfolio(portfolio)
    }

    suspend fun updatePortfolio(portfolio: PortfolioEntity) = withContext(Dispatchers.IO) {
        portfolioDao.updatePortfolio(portfolio)
    }

    suspend fun deletePortfolio(portfolio: PortfolioEntity) = withContext(Dispatchers.IO) {
        portfolioDao.deletePortfolio(portfolio)
    }

    // --- SAVING GOALS ---
    fun getAllSavingGoals(userId: String): Flow<List<SavingGoalEntity>> =
        savingGoalDao.getAllSavingGoals(userId)

    suspend fun insertSavingGoal(goal: SavingGoalEntity): Long = withContext(Dispatchers.IO) {
        savingGoalDao.insertSavingGoal(goal)
    }

    suspend fun updateSavingGoal(goal: SavingGoalEntity) = withContext(Dispatchers.IO) {
        savingGoalDao.updateSavingGoal(goal)
    }

    suspend fun deleteSavingGoal(goal: SavingGoalEntity) = withContext(Dispatchers.IO) {
        savingGoalDao.deleteSavingGoal(goal)
    }

    suspend fun addFundsToSavingGoal(
        userId: String,
        goalId: Long,
        addAmount: Double,
        walletId: Long,
        walletName: String,
        note: String
    ) = withContext(Dispatchers.IO) {
        val goal = savingGoalDao.getSavingGoalById(userId, goalId) ?: return@withContext
        val newAmount = goal.currentAmount + addAmount
        val isCompleted = newAmount >= goal.targetAmount
        savingGoalDao.updateSavingGoal(goal.copy(currentAmount = newAmount, isCompleted = isCompleted))

        // Create an investment/saving transaction
        val tx = TransactionEntity(
            userId = userId,
            type = "EXPENSE",
            amount = addAmount,
            categoryId = "cat_invest_exp",
            categoryName = "Tabungan: ${goal.title}",
            categoryColor = goal.color,
            categoryIcon = "savings",
            walletId = walletId,
            walletName = walletName,
            note = note.ifBlank { "Menabung untuk ${goal.title}" },
            date = System.currentTimeMillis()
        )
        transactionDao.insertTransaction(tx)
        recalculateWalletBalances(userId)
    }

    // --- BUDGETS ---
    fun getAllBudgets(userId: String): Flow<List<BudgetEntity>> =
        budgetDao.getAllBudgets(userId)

    suspend fun insertBudget(budget: BudgetEntity): Long = withContext(Dispatchers.IO) {
        budgetDao.insertBudget(budget)
    }

    suspend fun updateBudget(budget: BudgetEntity) = withContext(Dispatchers.IO) {
        budgetDao.updateBudget(budget)
    }

    suspend fun deleteBudget(budget: BudgetEntity) = withContext(Dispatchers.IO) {
        budgetDao.deleteBudget(budget)
    }

    // --- FINANCIAL NOTES ---
    fun getAllNotes(userId: String): Flow<List<FinancialNoteEntity>> =
        financialNoteDao.getAllNotes(userId)

    suspend fun insertNote(note: FinancialNoteEntity): Long = withContext(Dispatchers.IO) {
        financialNoteDao.insertNote(note)
    }

    suspend fun updateNote(note: FinancialNoteEntity) = withContext(Dispatchers.IO) {
        financialNoteDao.updateNote(note)
    }

    suspend fun deleteNote(note: FinancialNoteEntity) = withContext(Dispatchers.IO) {
        financialNoteDao.deleteNote(note)
    }

    // --- RECURRING TRANSACTIONS ---
    fun getAllRecurring(userId: String): Flow<List<RecurringTransactionEntity>> =
        recurringDao.getAllRecurring(userId)

    suspend fun insertRecurring(recurring: RecurringTransactionEntity): Long = withContext(Dispatchers.IO) {
        recurringDao.insertRecurring(recurring)
    }

    suspend fun updateRecurring(recurring: RecurringTransactionEntity) = withContext(Dispatchers.IO) {
        recurringDao.updateRecurring(recurring)
    }

    suspend fun deleteRecurring(recurring: RecurringTransactionEntity) = withContext(Dispatchers.IO) {
        recurringDao.deleteRecurring(recurring)
    }

    // --- ACCOUNT DELETION & PURGE ---
    suspend fun deleteAllUserData(userId: String) = withContext(Dispatchers.IO) {
        transactionDao.deleteAllByUser(userId)
        walletDao.deleteAllByUser(userId)
        portfolioDao.deleteAllByUser(userId)
        savingGoalDao.deleteAllByUser(userId)
        budgetDao.deleteAllByUser(userId)
        financialNoteDao.deleteAllByUser(userId)
        recurringDao.deleteAllByUser(userId)
    }

    // --- BACKUP & RESTORE ---
    suspend fun exportJsonBackup(userId: String): String = withContext(Dispatchers.IO) {
        val root = JSONObject()
        root.put("version", 1)
        root.put("userId", userId)
        root.put("exportedAt", System.currentTimeMillis())
        root.put("note", "FinPorto Backup Data")
        root.toString(2)
    }
}
