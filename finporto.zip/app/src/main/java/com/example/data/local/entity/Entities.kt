package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String,
    val type: String, // "INCOME", "EXPENSE", "TRANSFER"
    val amount: Double,
    val categoryId: String,
    val categoryName: String,
    val categoryColor: Long,
    val categoryIcon: String,
    val walletId: Long,
    val walletName: String,
    val targetWalletId: Long? = null,
    val targetWalletName: String? = null,
    val adminFee: Double = 0.0,
    val note: String = "",
    val date: Long = System.currentTimeMillis(),
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "wallets")
data class WalletEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String,
    val name: String,
    val type: String, // "CASH", "BANK", "EWALLET", "OTHER"
    val initialBalance: Double = 0.0,
    val currentBalance: Double = 0.0,
    val accountNumber: String = "",
    val color: Long = 0xFF0F766E,
    val icon: String = "account_balance_wallet",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "portfolios")
data class PortfolioEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String,
    val name: String,
    val type: String, // "INVESTMENT", "SAVINGS", "ASSET", "BUSINESS", "EMERGENCY_FUND", "OTHER"
    val currentValue: Double,
    val initialInvested: Double = 0.0,
    val targetValue: Double = 0.0,
    val color: Long = 0xFF8B5CF6,
    val icon: String = "trending_up",
    val notes: String = "",
    val lastUpdated: Long = System.currentTimeMillis()
)

@Entity(tableName = "saving_goals")
data class SavingGoalEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String,
    val title: String,
    val targetAmount: Double,
    val currentAmount: Double = 0.0,
    val targetDate: Long = System.currentTimeMillis(),
    val color: Long = 0xFF10B981,
    val icon: String = "savings",
    val notes: String = "",
    val isCompleted: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "budgets")
data class BudgetEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String,
    val categoryId: String,
    val categoryName: String,
    val categoryColor: Long = 0xFFEF4444,
    val limitAmount: Double,
    val period: String = "MONTHLY", // "MONTHLY", "WEEKLY"
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "financial_notes")
data class FinancialNoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String,
    val title: String,
    val content: String,
    val isPinned: Boolean = false,
    val colorTag: Long = 0xFF0F766E,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "recurring_transactions")
data class RecurringTransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String,
    val title: String,
    val type: String, // "INCOME", "EXPENSE"
    val amount: Double,
    val categoryId: String,
    val categoryName: String,
    val walletId: Long,
    val walletName: String,
    val interval: String = "MONTHLY", // "DAILY", "WEEKLY", "MONTHLY", "YEARLY"
    val nextDueDate: Long = System.currentTimeMillis(),
    val isActive: Boolean = true,
    val note: String = ""
)
