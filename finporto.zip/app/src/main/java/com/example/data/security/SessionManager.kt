package com.example.data.security

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "finporto_session_prefs")

data class UserSession(
    val userId: String = "",
    val name: String = "",
    val email: String = "",
    val photoUrl: String = "",
    val isLoggedIn: Boolean = false,
    val isGoogleAuth: Boolean = false,
    val pinCode: String = "",
    val isPinEnabled: Boolean = false,
    val isBiometricEnabled: Boolean = false,
    val autoLockMinutes: Int = 1, // 0 = Immediately, 1 = 1 Min, 5 = 5 Min
    val currency: String = "IDR",
    val riskProfile: String = "MODERATE" // "CONSERVATIVE", "MODERATE", "AGGRESSIVE"
)

class SessionManager(private val context: Context) {
    companion object {
        val KEY_USER_ID = stringPreferencesKey("user_id")
        val KEY_USER_NAME = stringPreferencesKey("user_name")
        val KEY_USER_EMAIL = stringPreferencesKey("user_email")
        val KEY_PHOTO_URL = stringPreferencesKey("photo_url")
        val KEY_IS_LOGGED_IN = booleanPreferencesKey("is_logged_in")
        val KEY_IS_GOOGLE_AUTH = booleanPreferencesKey("is_google_auth")
        val KEY_PIN_CODE = stringPreferencesKey("pin_code")
        val KEY_IS_PIN_ENABLED = booleanPreferencesKey("is_pin_enabled")
        val KEY_IS_BIOMETRIC_ENABLED = booleanPreferencesKey("is_biometric_enabled")
        val KEY_AUTO_LOCK_MINUTES = intPreferencesKey("auto_lock_minutes")
        val KEY_LAST_ACTIVE_TIME = longPreferencesKey("last_active_time")
        val KEY_CURRENCY = stringPreferencesKey("currency")
        val KEY_RISK_PROFILE = stringPreferencesKey("risk_profile")
    }

    val userSessionFlow: Flow<UserSession> = context.dataStore.data.map { prefs ->
        val userId = prefs[KEY_USER_ID] ?: ""
        val isLoggedIn = prefs[KEY_IS_LOGGED_IN] ?: false
        val pin = prefs[KEY_PIN_CODE] ?: ""
        UserSession(
            userId = userId,
            name = prefs[KEY_USER_NAME] ?: "",
            email = prefs[KEY_USER_EMAIL] ?: "",
            photoUrl = prefs[KEY_PHOTO_URL] ?: "",
            isLoggedIn = isLoggedIn && userId.isNotEmpty(),
            isGoogleAuth = prefs[KEY_IS_GOOGLE_AUTH] ?: false,
            pinCode = pin,
            isPinEnabled = prefs[KEY_IS_PIN_ENABLED] ?: false && pin.isNotEmpty(),
            isBiometricEnabled = prefs[KEY_IS_BIOMETRIC_ENABLED] ?: false,
            autoLockMinutes = prefs[KEY_AUTO_LOCK_MINUTES] ?: 1,
            currency = prefs[KEY_CURRENCY] ?: "IDR",
            riskProfile = prefs[KEY_RISK_PROFILE] ?: "MODERATE"
        )
    }

    suspend fun saveLoginSession(
        userId: String,
        name: String,
        email: String,
        photoUrl: String = "",
        isGoogleAuth: Boolean = true
    ) {
        context.dataStore.edit { prefs ->
            prefs[KEY_USER_ID] = userId
            prefs[KEY_USER_NAME] = name
            prefs[KEY_USER_EMAIL] = email
            prefs[KEY_PHOTO_URL] = photoUrl
            prefs[KEY_IS_LOGGED_IN] = true
            prefs[KEY_IS_GOOGLE_AUTH] = isGoogleAuth
            prefs[KEY_LAST_ACTIVE_TIME] = System.currentTimeMillis()
        }
    }

    suspend fun updatePin(pin: String, enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_PIN_CODE] = pin
            prefs[KEY_IS_PIN_ENABLED] = enabled
        }
    }

    suspend fun setBiometricEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[KEY_IS_BIOMETRIC_ENABLED] = enabled
        }
    }

    suspend fun setAutoLockMinutes(minutes: Int) {
        context.dataStore.edit { prefs ->
            prefs[KEY_AUTO_LOCK_MINUTES] = minutes
        }
    }

    suspend fun updateRiskProfile(profile: String) {
        context.dataStore.edit { prefs ->
            prefs[KEY_RISK_PROFILE] = profile
        }
    }

    suspend fun updateLastActiveTime() {
        context.dataStore.edit { prefs ->
            prefs[KEY_LAST_ACTIVE_TIME] = System.currentTimeMillis()
        }
    }

    suspend fun clearSession() {
        context.dataStore.edit { prefs ->
            prefs.clear()
        }
    }
}
