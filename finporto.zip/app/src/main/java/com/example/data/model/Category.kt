package com.example.data.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.*

data class TransactionCategory(
    val id: String,
    val name: String,
    val type: CategoryType,
    val color: Long,
    val iconName: String
)

enum class CategoryType {
    INCOME, EXPENSE, TRANSFER
}

object DefaultCategories {
    val expenseCategories = listOf(
        TransactionCategory("cat_food", "Makanan & Minuman", CategoryType.EXPENSE, CatFood.value.toLong(), "restaurant"),
        TransactionCategory("cat_transport", "Transportasi", CategoryType.EXPENSE, CatTransport.value.toLong(), "directions_car"),
        TransactionCategory("cat_shopping", "Belanja & Kebutuhan", CategoryType.EXPENSE, CatShopping.value.toLong(), "shopping_bag"),
        TransactionCategory("cat_bills", "Tagihan & Utilitas", CategoryType.EXPENSE, CatBills.value.toLong(), "receipt_long"),
        TransactionCategory("cat_health", "Kesehatan & Medis", CategoryType.EXPENSE, CatHealth.value.toLong(), "medical_services"),
        TransactionCategory("cat_education", "Pendidikan", CategoryType.EXPENSE, CatEducation.value.toLong(), "school"),
        TransactionCategory("cat_entertainment", "Hiburan & Rekreasi", CategoryType.EXPENSE, CatEntertainment.value.toLong(), "sports_esports"),
        TransactionCategory("cat_internet", "Internet & Pulsa", CategoryType.EXPENSE, CatInternet.value.toLong(), "wifi"),
        TransactionCategory("cat_invest_exp", "Investasi Keluar", CategoryType.EXPENSE, CatInvestment.value.toLong(), "trending_up"),
        TransactionCategory("cat_other_exp", "Lainnya", CategoryType.EXPENSE, CatOther.value.toLong(), "more_horiz")
    )

    val incomeCategories = listOf(
        TransactionCategory("cat_salary", "Gaji Pokok", CategoryType.INCOME, CatSalary.value.toLong(), "payments"),
        TransactionCategory("cat_bonus", "Bonus & THR", CategoryType.INCOME, CatBonus.value.toLong(), "military_tech"),
        TransactionCategory("cat_freelance", "Freelance & Proyek", CategoryType.INCOME, CatFreelance.value.toLong(), "laptop_mac"),
        TransactionCategory("cat_business", "Bisnis & Usaha", CategoryType.INCOME, CatTransport.value.toLong(), "storefront"),
        TransactionCategory("cat_investment_inc", "Dividen & Bunga Investasi", CategoryType.INCOME, CatInvestment.value.toLong(), "show_chart"),
        TransactionCategory("cat_gift", "Hadiah / Hibah", CategoryType.INCOME, CatShopping.value.toLong(), "card_giftcard"),
        TransactionCategory("cat_other_inc", "Pemasukan Lainnya", CategoryType.INCOME, CatOther.value.toLong(), "account_balance_wallet")
    )

    fun findCategory(id: String, type: String): TransactionCategory {
        val list = if (type == "INCOME") incomeCategories else expenseCategories
        return list.find { it.id == id } ?: TransactionCategory(
            id = id,
            name = if (id.isNotBlank()) id else "Lainnya",
            type = if (type == "INCOME") CategoryType.INCOME else CategoryType.EXPENSE,
            color = CatOther.value.toLong(),
            iconName = "category"
        )
    }
}
