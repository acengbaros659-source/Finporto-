package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions WHERE userId = :userId ORDER BY date DESC")
    fun getAllTransactions(userId: String): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE userId = :userId AND date >= :startTime AND date <= :endTime ORDER BY date DESC")
    fun getTransactionsByDateRange(userId: String, startTime: Long, endTime: Long): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE userId = :userId AND (walletId = :walletId OR targetWalletId = :walletId) ORDER BY date DESC")
    fun getTransactionsByWallet(userId: String, walletId: Long): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE id = :id AND userId = :userId LIMIT 1")
    suspend fun getTransactionById(userId: String, id: Long): TransactionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: TransactionEntity): Long

    @Update
    suspend fun updateTransaction(transaction: TransactionEntity)

    @Delete
    suspend fun deleteTransaction(transaction: TransactionEntity)

    @Query("DELETE FROM transactions WHERE id IN (:ids) AND userId = :userId")
    suspend fun deleteTransactionsByIds(userId: String, ids: List<Long>)

    @Query("DELETE FROM transactions WHERE userId = :userId")
    suspend fun deleteAllByUser(userId: String)
}

@Dao
interface WalletDao {
    @Query("SELECT * FROM wallets WHERE userId = :userId ORDER BY createdAt ASC")
    fun getAllWallets(userId: String): Flow<List<WalletEntity>>

    @Query("SELECT * FROM wallets WHERE id = :id AND userId = :userId LIMIT 1")
    suspend fun getWalletById(userId: String, id: Long): WalletEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWallet(wallet: WalletEntity): Long

    @Update
    suspend fun updateWallet(wallet: WalletEntity)

    @Delete
    suspend fun deleteWallet(wallet: WalletEntity)

    @Query("DELETE FROM wallets WHERE userId = :userId")
    suspend fun deleteAllByUser(userId: String)
}

@Dao
interface PortfolioDao {
    @Query("SELECT * FROM portfolios WHERE userId = :userId ORDER BY lastUpdated DESC")
    fun getAllPortfolios(userId: String): Flow<List<PortfolioEntity>>

    @Query("SELECT * FROM portfolios WHERE id = :id AND userId = :userId LIMIT 1")
    suspend fun getPortfolioById(userId: String, id: Long): PortfolioEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPortfolio(portfolio: PortfolioEntity): Long

    @Update
    suspend fun updatePortfolio(portfolio: PortfolioEntity)

    @Delete
    suspend fun deletePortfolio(portfolio: PortfolioEntity)

    @Query("DELETE FROM portfolios WHERE userId = :userId")
    suspend fun deleteAllByUser(userId: String)
}

@Dao
interface SavingGoalDao {
    @Query("SELECT * FROM saving_goals WHERE userId = :userId ORDER BY targetDate ASC")
    fun getAllSavingGoals(userId: String): Flow<List<SavingGoalEntity>>

    @Query("SELECT * FROM saving_goals WHERE id = :id AND userId = :userId LIMIT 1")
    suspend fun getSavingGoalById(userId: String, id: Long): SavingGoalEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavingGoal(goal: SavingGoalEntity): Long

    @Update
    suspend fun updateSavingGoal(goal: SavingGoalEntity)

    @Delete
    suspend fun deleteSavingGoal(goal: SavingGoalEntity)

    @Query("DELETE FROM saving_goals WHERE userId = :userId")
    suspend fun deleteAllByUser(userId: String)
}

@Dao
interface BudgetDao {
    @Query("SELECT * FROM budgets WHERE userId = :userId ORDER BY createdAt ASC")
    fun getAllBudgets(userId: String): Flow<List<BudgetEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBudget(budget: BudgetEntity): Long

    @Update
    suspend fun updateBudget(budget: BudgetEntity)

    @Delete
    suspend fun deleteBudget(budget: BudgetEntity)

    @Query("DELETE FROM budgets WHERE userId = :userId")
    suspend fun deleteAllByUser(userId: String)
}

@Dao
interface FinancialNoteDao {
    @Query("SELECT * FROM financial_notes WHERE userId = :userId ORDER BY isPinned DESC, updatedAt DESC")
    fun getAllNotes(userId: String): Flow<List<FinancialNoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: FinancialNoteEntity): Long

    @Update
    suspend fun updateNote(note: FinancialNoteEntity)

    @Delete
    suspend fun deleteNote(note: FinancialNoteEntity)

    @Query("DELETE FROM financial_notes WHERE userId = :userId")
    suspend fun deleteAllByUser(userId: String)
}

@Dao
interface RecurringDao {
    @Query("SELECT * FROM recurring_transactions WHERE userId = :userId ORDER BY nextDueDate ASC")
    fun getAllRecurring(userId: String): Flow<List<RecurringTransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecurring(recurring: RecurringTransactionEntity): Long

    @Update
    suspend fun updateRecurring(recurring: RecurringTransactionEntity)

    @Delete
    suspend fun deleteRecurring(recurring: RecurringTransactionEntity)

    @Query("DELETE FROM recurring_transactions WHERE userId = :userId")
    suspend fun deleteAllByUser(userId: String)
}
