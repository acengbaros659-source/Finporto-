package com.example.data.ai

import com.example.BuildConfig
import com.example.data.local.entity.*
import com.example.util.CurrencyUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiService {
    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun analyzeFinancialHealth(
        totalIncome: Double,
        totalExpense: Double,
        netBalance: Double,
        portfolios: List<PortfolioEntity>,
        savingGoals: List<SavingGoalEntity>,
        budgets: List<BudgetEntity>,
        topExpenses: List<Pair<String, Double>>,
        userQuestion: String = ""
    ): String = withContext(Dispatchers.IO) {
        val totalPortfolioValue = portfolios.sumOf { it.currentValue }
        val totalSavingsValue = savingGoals.sumOf { it.currentAmount }
        val savingsRate = if (totalIncome > 0) ((totalIncome - totalExpense) / totalIncome * 100).coerceAtLeast(0.0) else 0.0

        // Format user financial context
        val contextBuilder = StringBuilder()
        contextBuilder.appendLine("RINGKASAN DATA KEUANGAN PENGGUNA SAAT INI:")
        contextBuilder.appendLine("- Total Pemasukan: ${CurrencyUtils.formatRupiah(totalIncome)}")
        contextBuilder.appendLine("- Total Pengeluaran: ${CurrencyUtils.formatRupiah(totalExpense)}")
        contextBuilder.appendLine("- Saldo Bersih: ${CurrencyUtils.formatRupiah(netBalance)}")
        contextBuilder.appendLine("- Total Tabungan Terkumpul: ${CurrencyUtils.formatRupiah(totalSavingsValue)}")
        contextBuilder.appendLine("- Total Aset/Portofolio: ${CurrencyUtils.formatRupiah(totalPortfolioValue)}")
        contextBuilder.appendLine("- Rasio Tabungan (Savings Rate): ${"%.1f".format(savingsRate)}%")
        
        if (topExpenses.isNotEmpty()) {
            contextBuilder.appendLine("- Pengeluaran Terbesar per Kategori:")
            topExpenses.take(5).forEach { (cat, amt) ->
                contextBuilder.appendLine("  * $cat: ${CurrencyUtils.formatRupiah(amt)}")
            }
        } else {
            contextBuilder.appendLine("- Belum ada catatan pengeluaran rinci.")
        }

        if (savingGoals.isNotEmpty()) {
            contextBuilder.appendLine("- Target Tabungan:")
            savingGoals.forEach { g ->
                val progress = if (g.targetAmount > 0) (g.currentAmount / g.targetAmount * 100).toInt() else 0
                contextBuilder.appendLine("  * ${g.title}: ${CurrencyUtils.formatRupiah(g.currentAmount)} / ${CurrencyUtils.formatRupiah(g.targetAmount)} ($progress%)")
            }
        }

        val prompt = if (userQuestion.isNotBlank()) {
            """
            Kamu adalah Asisten Finansial AI FinPorto profesional yang ramah, bijak, dan berbasis data nyata pengguna.
            
            $contextBuilder
            
            Pertanyaan/Permintaan Pengguna:
            "$userQuestion"
            
            Instruksi:
            1. Jawab secara spesifik dengan mengacu pada angka data nyata pengguna di atas.
            2. Berikan saran realistis, ramah, dan actionable dalam bahasa Indonesia.
            3. Jika data pengguna masih Rp0 atau sangat sedikit, jelaskan dengan sopan dan berikan langkah awal mengatur anggaran.
            """.trimIndent()
        } else {
            """
            Kamu adalah Asisten Finansial AI FinPorto profesional.
            
            $contextBuilder
            
            Lakukan analisis kesehatan keuangan komprehensif untuk pengguna:
            1. **Evaluasi Arus Kas (Cashflow Health)**: Apakah surplus atau defisit, evaluasi rasio tabungan.
            2. **Analisis Pengeluaran**: Identifikasi kategori terbesar dan potensi pemborosan.
            3. **Rekomendasi Alokasi (Metode 50/30/20)**: Saran pembagian Kebutuhan Pokok, Keinginan, dan Tabungan/Investasi.
            4. **Tips Penghematan & Action Plan**: 3 langkah konkrit yang bisa dilakukan minggu ini.
            
            Tulis dengan format rapi, menggunakan bullet points, tone ramah dan memotivasi dalam Bahasa Indonesia.
            """.trimIndent()
        }

        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            // Local Intelligent Heuristic Fallback
            return@withContext generateLocalHeuristicInsight(
                totalIncome = totalIncome,
                totalExpense = totalExpense,
                netBalance = netBalance,
                savingsRate = savingsRate,
                topExpenses = topExpenses,
                savingGoals = savingGoals,
                totalPortfolio = totalPortfolioValue
            )
        }

        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"
            
            val requestBodyJson = JSONObject().apply {
                val contents = JSONArray().apply {
                    val contentObj = JSONObject().apply {
                        val parts = JSONArray().apply {
                            put(JSONObject().put("text", prompt))
                        }
                        put("parts", parts)
                    }
                    put(contentObj)
                }
                put("contents", contents)
                
                val genConfig = JSONObject().apply {
                    put("temperature", 0.7)
                    put("topP", 0.9)
                }
                put("generationConfig", genConfig)
            }

            val request = Request.Builder()
                .url(url)
                .post(requestBodyJson.toString().toRequestBody(jsonMediaType))
                .build()

            val response = client.newCall(request).execute()
            val responseString = response.body?.string() ?: ""

            if (response.isSuccessful && responseString.isNotEmpty()) {
                val jsonResponse = JSONObject(responseString)
                val candidates = jsonResponse.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val candidate = candidates.getJSONObject(0)
                    val content = candidate.optJSONObject("content")
                    val parts = content?.optJSONArray("parts")
                    val text = parts?.optJSONObject(0)?.optString("text")
                    if (!text.isNullOrBlank()) {
                        return@withContext text
                    }
                }
            }
            
            // If API returned error or empty, fallback gracefully
            generateLocalHeuristicInsight(totalIncome, totalExpense, netBalance, savingsRate, topExpenses, savingGoals, totalPortfolioValue)
        } catch (e: Exception) {
            generateLocalHeuristicInsight(totalIncome, totalExpense, netBalance, savingsRate, topExpenses, savingGoals, totalPortfolioValue)
        }
    }

    private fun generateLocalHeuristicInsight(
        totalIncome: Double,
        totalExpense: Double,
        netBalance: Double,
        savingsRate: Double,
        topExpenses: List<Pair<String, Double>>,
        savingGoals: List<SavingGoalEntity>,
        totalPortfolio: Double
    ): String {
        val sb = StringBuilder()
        sb.appendLine("💡 **Analisis Keuangan Cerdas FinPorto**\n")

        if (totalIncome == 0.0 && totalExpense == 0.0) {
            sb.appendLine("📊 **Kondisi Saat Ini**: Akun Anda baru dan belum memiliki catatan transaksi.")
            sb.appendLine("\n✨ **Langkah Awal yang Direkomendasikan**:")
            sb.appendLine("1. Tambahkan dompet/rekening utama Anda di menu **Dompet**.")
            sb.appendLine("2. Catat pemasukan rutin seperti gaji atau usaha.")
            sb.appendLine("3. Buat anggaran bulanan untuk mengontrol pengeluaran.")
            sb.appendLine("4. Tentukan target tabungan pertama Anda!")
            return sb.toString()
        }

        // Cash flow status
        if (netBalance >= 0) {
            sb.appendLine("✅ **Arus Kas Positif**: Surplus ${CurrencyUtils.formatRupiah(netBalance)}.")
            if (savingsRate >= 20) {
                sb.appendLine("🌟 Rasio tabungan Anda sangat sehat (${"%.1f".format(savingsRate)}% dari total pemasukan).")
            } else {
                sb.appendLine("📈 Rasio tabungan Anda saat ini ${"%.1f".format(savingsRate)}%. Idealnya tingkatkan ke minimal 20%.")
            }
        } else {
            sb.appendLine("⚠️ **Peringatan Defisit**: Pengeluaran Anda melebihi pemasukan sebesar ${CurrencyUtils.formatRupiah(-netBalance)}.")
            sb.appendLine("Disarankan untuk meninjau kembali pengeluaran non-esensial.")
        }

        // Top category analysis
        if (topExpenses.isNotEmpty()) {
            val top = topExpenses.first()
            sb.appendLine("\n🏷️ **Pengeluaran Terbesar**: ${top.first} (${CurrencyUtils.formatRupiah(top.second)})")
            if (top.second > totalIncome * 0.4 && totalIncome > 0) {
                sb.appendLine("Kategori ini memakan lebih dari 40% pemasukan Anda. Pertimbangkan alokasi ulang.")
            }
        }

        // 50/30/20 Rule check
        if (totalIncome > 0) {
            val needsBudget = totalIncome * 0.50
            val wantsBudget = totalIncome * 0.30
            val savingsBudget = totalIncome * 0.20
            sb.appendLine("\n📐 **Panduan Formula 50 / 30 / 20 Ideal**:")
            sb.appendLine("• Kebutuhan Pokok (50%): maks ${CurrencyUtils.formatRupiah(needsBudget)}")
            sb.appendLine("• Keinginan / Lifestyle (30%): maks ${CurrencyUtils.formatRupiah(wantsBudget)}")
            sb.appendLine("• Tabungan & Investasi (20%): min ${CurrencyUtils.formatRupiah(savingsBudget)}")
        }

        // Goals progress
        if (savingGoals.isNotEmpty()) {
            val completed = savingGoals.count { it.isCompleted }
            sb.appendLine("\n🎯 **Progress Target Tabungan**: $completed dari ${savingGoals.size} target tercapai.")
        }

        if (totalPortfolio > 0) {
            sb.appendLine("💼 **Total Portofolio & Aset**: ${CurrencyUtils.formatRupiah(totalPortfolio)}.")
        }

        sb.appendLine("\n_Insight ini dihitung secara real-time berdasarkan data keuangan aktual Anda._")
        return sb.toString()
    }
}
