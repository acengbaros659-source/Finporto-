package com.example.ui.screens.settings

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.model.ExportHelper
import com.example.ui.theme.*
import com.example.ui.viewmodel.FinPortoViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: FinPortoViewModel,
    onNavigateToGoals: () -> Unit,
    onNavigateToAnalytics: () -> Unit,
    onNavigateToRecurring: () -> Unit,
    onNavigateToNotes: () -> Unit,
    onNavigateToAi: () -> Unit,
    onOpenCalculator: () -> Unit,
    onLogout: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val userSession by viewModel.userSession.collectAsStateWithLifecycle()
    val transactions by viewModel.allTransactions.collectAsStateWithLifecycle()

    var showPinDialog by remember { mutableStateOf(false) }
    var showLogoutConfirm by remember { mutableStateOf(false) }
    var showDeleteAccountConfirm by remember { mutableStateOf(false) }
    var showRiskProfileDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Menu & Pengaturan", fontWeight = FontWeight.Bold, color = PolishTextPrimary) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PolishBg)
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(PolishBg),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. User Profile Card
            item {
                Card(
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = RoyalBlue),
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(4.dp, RoundedCornerShape(22.dp))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(modifier = Modifier.size(54.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(50.dp)
                                    .background(Color.White.copy(alpha = 0.25f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = userSession.name.take(1).uppercase().ifEmpty { "U" },
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White
                                )
                            }
                            if (userSession.isGoogleAuth) {
                                Box(
                                    modifier = Modifier
                                        .size(20.dp)
                                        .align(Alignment.BottomEnd)
                                        .background(Color.White, CircleShape)
                                        .padding(2.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Image(
                                        painter = painterResource(id = R.drawable.ic_google_logo),
                                        contentDescription = "Google",
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = userSession.name.ifBlank { "Pengguna FinPorto" },
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = userSession.email.ifBlank { "user@finporto.app" },
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.85f),
                                fontSize = 12.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Surface(
                                color = Color.White.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = if (userSession.isGoogleAuth) "Akun Google Terverifikasi" else "Akun Mandiri",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontSize = 10.sp,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }

            // 2. Feature Hub (Pusat Fitur Finansial)
            item {
                Text(
                    text = "FITUR KEUANGAN",
                    style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.2.sp),
                    fontWeight = FontWeight.Bold,
                    color = PolishTextSecondary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = PolishSurface),
                    border = BorderStroke(1.dp, PolishBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        HubFeatureItem(
                            icon = Icons.Default.Savings,
                            iconBg = BlueCardBg,
                            iconColor = RoyalBlue,
                            title = "Target Tabungan & Budget",
                            subtitle = "Kelola impian finansial & alokasi anggaran bulanan",
                            onClick = onNavigateToGoals
                        )
                        HorizontalDivider(color = PolishBorder.copy(alpha = 0.6f))
                        HubFeatureItem(
                            icon = Icons.Default.BarChart,
                            iconBg = PurpleCardBg,
                            iconColor = InvestmentPurple,
                            title = "Statistik & Grafik Cashflow",
                            subtitle = "Visualisasi arus kas bulanan & tren saldo",
                            onClick = onNavigateToAnalytics
                        )
                        HorizontalDivider(color = PolishBorder.copy(alpha = 0.6f))
                        HubFeatureItem(
                            icon = Icons.Default.EventRepeat,
                            iconBg = WarningAmberBg,
                            iconColor = WarningAmber,
                            title = "Tagihan Rutin & Pengingat",
                            subtitle = "Catat biaya bulanan (listrik, internet, sewa)",
                            onClick = onNavigateToRecurring
                        )
                        HorizontalDivider(color = PolishBorder.copy(alpha = 0.6f))
                        HubFeatureItem(
                            icon = Icons.Default.StickyNote2,
                            iconBg = PolishSurfaceVariant,
                            iconColor = PolishTextSecondary,
                            title = "Catatan Rencana Finansial",
                            subtitle = "Catatan strategi keuangan & target belanja",
                            onClick = onNavigateToNotes
                        )
                        HorizontalDivider(color = PolishBorder.copy(alpha = 0.6f))
                        HubFeatureItem(
                            icon = Icons.Default.AutoAwesome,
                            iconBg = BlueContainer,
                            iconColor = RoyalBlue,
                            title = "Asisten AI Finansial",
                            subtitle = "Analisis portofolio & tips hemat cerdas dengan AI",
                            badge = "AI",
                            onClick = onNavigateToAi
                        )
                        HorizontalDivider(color = PolishBorder.copy(alpha = 0.6f))
                        HubFeatureItem(
                            icon = Icons.Default.Calculate,
                            iconBg = IncomeGreenBg,
                            iconColor = IncomeGreen,
                            title = "Kalkulator Finansial",
                            subtitle = "Hitung cepat operasi keuangan & persentase",
                            onClick = onOpenCalculator
                        )
                    }
                }
            }

            // 3. Security Section
            item {
                Text(
                    text = "KEAMANAN & PRIVASI",
                    style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.2.sp),
                    fontWeight = FontWeight.Bold,
                    color = PolishTextSecondary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = PolishSurface),
                    border = BorderStroke(1.dp, PolishBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        SettingsItemRow(
                            icon = Icons.Default.Lock,
                            title = "Kunci PIN Keamanan",
                            subtitle = if (userSession.isPinEnabled) "PIN Aktif (${userSession.pinCode.length} digit)" else "Nonaktif",
                            trailing = {
                                Switch(
                                    checked = userSession.isPinEnabled,
                                    onCheckedChange = { showPinDialog = true },
                                    colors = SwitchDefaults.colors(checkedThumbColor = RoyalBlue)
                                )
                            },
                            onClick = { showPinDialog = true }
                        )
                        HorizontalDivider(color = PolishBorder.copy(alpha = 0.6f))
                        SettingsItemRow(
                            icon = Icons.Default.Fingerprint,
                            title = "Buka Kunci Biometrik",
                            subtitle = if (userSession.isBiometricEnabled) "Aktif" else "Nonaktif",
                            trailing = {
                                Switch(
                                    checked = userSession.isBiometricEnabled,
                                    onCheckedChange = { enabled ->
                                        scope.launch { viewModel.sessionManager.setBiometricEnabled(enabled) }
                                    },
                                    colors = SwitchDefaults.colors(checkedThumbColor = RoyalBlue)
                                )
                            },
                            onClick = {
                                scope.launch { viewModel.sessionManager.setBiometricEnabled(!userSession.isBiometricEnabled) }
                            }
                        )
                    }
                }
            }

            // 4. Financial Preferences
            item {
                Text(
                    text = "PREFERENSI FINANSIAL",
                    style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.2.sp),
                    fontWeight = FontWeight.Bold,
                    color = PolishTextSecondary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = PolishSurface),
                    border = BorderStroke(1.dp, PolishBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        SettingsItemRow(
                            icon = Icons.Default.MonetizationOn,
                            title = "Mata Uang Default",
                            subtitle = "Rupiah Indonesia (IDR - Rp)",
                            onClick = {}
                        )
                        HorizontalDivider(color = PolishBorder.copy(alpha = 0.6f))
                        SettingsItemRow(
                            icon = Icons.Default.TrendingUp,
                            title = "Profil Risiko Investasi",
                            subtitle = when (userSession.riskProfile) {
                                "CONSERVATIVE" -> "Konservatif (Aman & Stabil)"
                                "AGGRESSIVE" -> "Agresif (High Risk High Return)"
                                else -> "Moderat (Seimbang)"
                            },
                            onClick = { showRiskProfileDialog = true }
                        )
                    }
                }
            }

            // 5. Data & Export
            item {
                Text(
                    text = "CADANGAN & EKSPOR",
                    style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.2.sp),
                    fontWeight = FontWeight.Bold,
                    color = PolishTextSecondary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = PolishSurface),
                    border = BorderStroke(1.dp, PolishBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        SettingsItemRow(
                            icon = Icons.Default.FileDownload,
                            title = "Ekspor Laporan Transaksi (CSV)",
                            subtitle = "Bagikan data dalam format spreadsheet RFC 4180",
                            onClick = {
                                val csv = ExportHelper.generateTransactionsCsv(transactions)
                                ExportHelper.shareCsvFile(context, csv)
                            }
                        )
                    }
                }
            }

            // 6. Account Actions
            item {
                Text(
                    text = "SESI AKUN",
                    style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.2.sp),
                    fontWeight = FontWeight.Bold,
                    color = PolishTextSecondary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = PolishSurface),
                    border = BorderStroke(1.dp, PolishBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        SettingsItemRow(
                            icon = Icons.Default.Logout,
                            title = "Keluar Akun",
                            subtitle = "Keluar dari sesi FinPorto saat ini",
                            tint = WarningAmber,
                            onClick = { showLogoutConfirm = true }
                        )
                        HorizontalDivider(color = PolishBorder.copy(alpha = 0.6f))
                        SettingsItemRow(
                            icon = Icons.Default.DeleteForever,
                            title = "Hapus Akun & Semua Data",
                            subtitle = "Hapus permanen seluruh portofolio & transaksi",
                            tint = ExpenseRed,
                            onClick = { showDeleteAccountConfirm = true }
                        )
                    }
                }
            }

            item {
                Text(
                    text = "FinPorto v1.0.0 • Akun: ${userSession.email}",
                    style = MaterialTheme.typography.bodySmall,
                    color = PolishTextSecondary,
                    fontSize = 11.sp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }

            item { Spacer(modifier = Modifier.height(32.dp)) }
        }
    }

    // PIN Setup Dialog
    if (showPinDialog) {
        var inputPin by remember { mutableStateOf("") }
        var isPinEnabled by remember { mutableStateOf(userSession.isPinEnabled) }

        AlertDialog(
            onDismissRequest = { showPinDialog = false },
            title = { Text("Pengaturan PIN Keamanan", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "PIN 4 atau 6 digit akan diminta setiap kali membuka aplikasi.",
                        style = MaterialTheme.typography.bodySmall,
                        color = PolishTextSecondary
                    )
                    OutlinedTextField(
                        value = inputPin,
                        onValueChange = { if (it.length <= 6) inputPin = it.filter { c -> c.isDigit() } },
                        label = { Text("Masukkan PIN Baru (4-6 digit)") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("pin_setup_input")
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Aktifkan Kunci PIN", fontWeight = FontWeight.Medium)
                        Switch(
                            checked = isPinEnabled,
                            onCheckedChange = { isPinEnabled = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = RoyalBlue)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            viewModel.sessionManager.updatePin(inputPin, isPinEnabled)
                        }
                        showPinDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("save_pin_setup_btn")
                ) { Text("Simpan PIN", fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { showPinDialog = false }) { Text("Batal") } }
        )
    }

    // Risk Profile Dialog
    if (showRiskProfileDialog) {
        val options = listOf(
            Triple("CONSERVATIVE", "Konservatif", "Fokus pada keamanan modal dan aset likuid (Deposito, Kas, Emas)"),
            Triple("MODERATE", "Moderat", "Keseimbangan antara pertumbuhan dan keamanan (Reksadana, Obligasi)"),
            Triple("AGGRESSIVE", "Agresif", "Mengejar imbal hasil tinggi dengan toleransi volatilitas (Saham, Kripto)")
        )

        AlertDialog(
            onDismissRequest = { showRiskProfileDialog = false },
            title = { Text("Pilih Profil Risiko Finansial", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    options.forEach { (key, title, desc) ->
                        val isSelected = userSession.riskProfile == key
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) BlueContainer else PolishSurfaceVariant
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    scope.launch { viewModel.sessionManager.updateRiskProfile(key) }
                                    showRiskProfileDialog = false
                                }
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = title,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) OnBlueContainer else PolishTextPrimary
                                )
                                Text(
                                    text = desc,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (isSelected) OnBlueContainer.copy(alpha = 0.8f) else PolishTextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showRiskProfileDialog = false }) { Text("Tutup") }
            }
        )
    }

    // Logout Confirmation Dialog
    if (showLogoutConfirm) {
        AlertDialog(
            onDismissRequest = { showLogoutConfirm = false },
            title = { Text("Konfirmasi Keluar Akun", fontWeight = FontWeight.Bold) },
            text = { Text("Apakah Anda yakin ingin keluar dari akun FinPorto Anda?") },
            confirmButton = {
                Button(
                    onClick = {
                        showLogoutConfirm = false
                        viewModel.logout()
                        onLogout()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = WarningAmber),
                    shape = RoundedCornerShape(12.dp)
                ) { Text("Keluar", fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutConfirm = false }) { Text("Batal") }
            }
        )
    }

    // Delete Account Confirmation Dialog
    if (showDeleteAccountConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteAccountConfirm = false },
            title = { Text("Hapus Semua Data Portofolio?", fontWeight = FontWeight.Bold, color = ExpenseRed) },
            text = {
                Text("Tindakan ini akan menghapus permanen seluruh transaksi, dompet, aset portofolio, dan target tabungan Anda. Data tidak dapat dipulihkan kembali.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteAccountConfirm = false
                        scope.launch {
                            viewModel.repository.deleteAllUserData(userSession.userId)
                            viewModel.logout()
                            onLogout()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed),
                    shape = RoundedCornerShape(12.dp)
                ) { Text("Hapus Permanen", fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteAccountConfirm = false }) { Text("Batal") }
            }
        )
    }
}

@Composable
private fun HubFeatureItem(
    icon: ImageVector,
    iconBg: Color,
    iconColor: Color,
    title: String,
    subtitle: String,
    badge: String? = null,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .background(iconBg, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = iconColor,
                modifier = Modifier.size(22.dp)
            )
        }
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = PolishTextPrimary
                )
                if (badge != null) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        color = CatShopping,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = badge,
                            color = Color.White,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                        )
                    }
                }
            }
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = PolishTextSecondary,
                fontSize = 11.sp
            )
        }
        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = null,
            tint = PolishBorderSubtle,
            modifier = Modifier.size(18.dp)
        )
    }
}

@Composable
private fun SettingsItemRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    tint: Color = RoyalBlue,
    trailing: (@Composable () -> Unit)? = null,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .background(tint.copy(alpha = 0.12f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = title, tint = tint, modifier = Modifier.size(20.dp))
        }
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = PolishTextPrimary)
            Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = PolishTextSecondary, fontSize = 11.sp)
        }
        if (trailing != null) {
            trailing()
        } else {
            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = PolishBorderSubtle, modifier = Modifier.size(18.dp))
        }
    }
}
