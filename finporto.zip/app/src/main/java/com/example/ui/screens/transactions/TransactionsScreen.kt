package com.example.ui.screens.transactions

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.TransactionEntity
import com.example.data.local.entity.WalletEntity
import com.example.data.model.DefaultCategories
import com.example.ui.components.CalculatorDialog
import com.example.ui.theme.*
import com.example.ui.viewmodel.FinPortoViewModel
import com.example.ui.viewmodel.TransactionSortOption
import com.example.util.CurrencyUtils
import com.example.util.DateUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransactionsScreen(
    viewModel: FinPortoViewModel,
    onOpenCalculator: () -> Unit
) {
    val transactions by viewModel.filteredTransactions.collectAsStateWithLifecycle()
    val searchQuery by viewModel.transactionSearchQuery.collectAsStateWithLifecycle()
    val selectedType by viewModel.selectedTypeFilter.collectAsStateWithLifecycle()
    val selectedSort by viewModel.transactionSort.collectAsStateWithLifecycle()
    val wallets by viewModel.allWallets.collectAsStateWithLifecycle()

    var showAddEditSheet by remember { mutableStateOf(false) }
    var transactionToEdit by remember { mutableStateOf<TransactionEntity?>(null) }
    var selectedTxForDetail by remember { mutableStateOf<TransactionEntity?>(null) }

    // Multi-selection for bulk delete
    var isSelectionMode by remember { mutableStateOf(false) }
    var selectedIds by remember { mutableStateOf(setOf<Long>()) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            if (isSelectionMode) {
                TopAppBar(
                    title = { Text("${selectedIds.size} dipilih", fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = {
                            isSelectionMode = false
                            selectedIds = emptySet()
                        }) {
                            Icon(Icons.Default.Close, contentDescription = "Batal")
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = { showDeleteConfirmDialog = true },
                            enabled = selectedIds.isNotEmpty(),
                            modifier = Modifier.testTag("bulk_delete_btn")
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Hapus Terpilih", tint = ExpenseRed)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                )
            } else {
                TopAppBar(
                    title = { Text("Riwayat Transaksi", fontWeight = FontWeight.Bold, color = PolishTextPrimary) },
                    actions = {
                        IconButton(onClick = { showAddEditSheet = true }, modifier = Modifier.testTag("add_tx_appbar_btn")) {
                            Icon(Icons.Default.AddCircle, contentDescription = "Tambah", tint = RoyalBlue)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = PolishBg)
                )
            }
        },
        floatingActionButton = {
            if (!isSelectionMode) {
                ExtendedFloatingActionButton(
                    onClick = {
                        transactionToEdit = null
                        showAddEditSheet = true
                    },
                    containerColor = RoyalBlue,
                    contentColor = Color.White,
                    icon = { Icon(Icons.Default.Add, contentDescription = "Tambah Transaksi") },
                    text = { Text("Transaksi Baru", fontWeight = FontWeight.Bold) },
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.testTag("fab_add_tx_screen")
                )
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(PolishBg)
        ) {
            // Search & Sort Header
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(PolishSurface)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.transactionSearchQuery.value = it },
                    placeholder = { Text("Cari catatan, kategori, dompet...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.transactionSearchQuery.value = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Hapus")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().testTag("tx_search_input")
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Type Filter Chips (Semua, Pemasukan, Pengeluaran, Transfer)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val types = listOf(
                        Pair("ALL", "Semua"),
                        Pair("INCOME", "Pemasukan"),
                        Pair("EXPENSE", "Pengeluaran"),
                        Pair("TRANSFER", "Transfer")
                    )
                    types.forEach { (typeKey, label) ->
                        val isSelected = selectedType == typeKey
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.selectedTypeFilter.value = typeKey },
                            label = { Text(label, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PrimaryTeal,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }

            // Transaction List
            if (transactions.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize().padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.ReceiptLong,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Belum ada riwayat.",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Transaksi yang Anda tambahkan akan langsung muncul di sini.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(transactions, key = { it.id }) { tx ->
                        val isSelected = selectedIds.contains(tx.id)
                        TransactionCardItem(
                            tx = tx,
                            isSelectionMode = isSelectionMode,
                            isSelected = isSelected,
                            onClick = {
                                if (isSelectionMode) {
                                    selectedIds = if (isSelected) selectedIds - tx.id else selectedIds + tx.id
                                    if (selectedIds.isEmpty()) isSelectionMode = false
                                } else {
                                    selectedTxForDetail = tx
                                }
                            },
                            onLongClick = {
                                isSelectionMode = true
                                selectedIds = selectedIds + tx.id
                            }
                        )
                    }
                }
            }
        }
    }

    // Add / Edit Transaction Sheet
    if (showAddEditSheet) {
        AddEditTransactionBottomSheet(
            transactionToEdit = transactionToEdit,
            wallets = wallets,
            onDismiss = {
                showAddEditSheet = false
                transactionToEdit = null
            },
            onSave = { type, amount, catId, catName, catColor, catIcon, walletId, walletName, targetWId, targetWName, adminFee, note, date ->
                if (transactionToEdit != null) {
                    viewModel.updateTransaction(
                        transactionToEdit!!.copy(
                            type = type,
                            amount = amount,
                            categoryId = catId,
                            categoryName = catName,
                            categoryColor = catColor,
                            categoryIcon = catIcon,
                            walletId = walletId,
                            walletName = walletName,
                            targetWalletId = targetWId,
                            targetWalletName = targetWName,
                            adminFee = adminFee,
                            note = note,
                            date = date
                        )
                    )
                } else {
                    viewModel.addTransaction(
                        type = type,
                        amount = amount,
                        categoryId = catId,
                        categoryName = catName,
                        categoryColor = catColor,
                        categoryIcon = catIcon,
                        walletId = walletId,
                        walletName = walletName,
                        targetWalletId = targetWId,
                        targetWalletName = targetWName,
                        adminFee = adminFee,
                        note = note,
                        date = date
                    )
                }
                showAddEditSheet = false
                transactionToEdit = null
            }
        )
    }

    // Detail Bottom Sheet
    if (selectedTxForDetail != null) {
        TransactionDetailBottomSheet(
            tx = selectedTxForDetail!!,
            onDismiss = { selectedTxForDetail = null },
            onEdit = {
                transactionToEdit = selectedTxForDetail
                selectedTxForDetail = null
                showAddEditSheet = true
            },
            onDelete = {
                viewModel.deleteTransaction(selectedTxForDetail!!)
                selectedTxForDetail = null
            }
        )
    }

    // Confirm Bulk Delete Dialog
    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = { Text("Hapus Transaksi?", fontWeight = FontWeight.Bold) },
            text = { Text("Apakah Anda yakin ingin menghapus ${selectedIds.size} transaksi terpilih? Saldo akan disesuaikan secara otomatis.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteMultipleTransactions(selectedIds.toList())
                        selectedIds = emptySet()
                        isSelectionMode = false
                        showDeleteConfirmDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed)
                ) {
                    Text("Hapus", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) { Text("Batal") }
            }
        )
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun TransactionCardItem(
    tx: TransactionEntity,
    isSelectionMode: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val isIncome = tx.type == "INCOME"
    val isTransfer = tx.type == "TRANSFER"

    val color = when {
        isTransfer -> TransferBlue
        isIncome -> IncomeGreen
        else -> Color(tx.categoryColor)
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) PrimaryTeal.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isSelectionMode) {
                Checkbox(
                    checked = isSelected,
                    onCheckedChange = { onClick() },
                    colors = CheckboxDefaults.colors(checkedColor = PrimaryTeal)
                )
                Spacer(modifier = Modifier.width(8.dp))
            }

            Box(
                modifier = Modifier.size(44.dp).background(color.copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when {
                        isTransfer -> Icons.Default.SwapHoriz
                        isIncome -> Icons.AutoMirrored.Filled.TrendingUp
                        else -> Icons.AutoMirrored.Filled.TrendingDown
                    },
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = tx.categoryName,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (tx.note.isNotBlank()) {
                    Text(
                        text = tx.note,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Text(
                    text = "${tx.walletName}${if (tx.targetWalletName != null) " ➔ ${tx.targetWalletName}" else ""} • ${DateUtils.formatDateTime(tx.date)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Text(
                text = "${if (isIncome) "+" else if (isTransfer) "" else "-"}${CurrencyUtils.formatRupiah(tx.amount)}",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = when {
                    isTransfer -> TransferBlue
                    isIncome -> IncomeGreen
                    else -> ExpenseRed
                }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditTransactionBottomSheet(
    transactionToEdit: TransactionEntity?,
    wallets: List<WalletEntity>,
    onDismiss: () -> Unit,
    onSave: (
        type: String,
        amount: Double,
        catId: String,
        catName: String,
        catColor: Long,
        catIcon: String,
        walletId: Long,
        walletName: String,
        targetWalletId: Long?,
        targetWalletName: String?,
        adminFee: Double,
        note: String,
        date: Long
    ) -> Unit
) {
    var type by remember { mutableStateOf(transactionToEdit?.type ?: "EXPENSE") }
    var amountText by remember { mutableStateOf(transactionToEdit?.amount?.toInt()?.toString() ?: "") }
    var note by remember { mutableStateOf(transactionToEdit?.note ?: "") }
    var adminFeeText by remember { mutableStateOf(if (transactionToEdit?.adminFee ?: 0.0 > 0) transactionToEdit!!.adminFee.toInt().toString() else "") }
    var selectedDate by remember { mutableLongStateOf(transactionToEdit?.date ?: System.currentTimeMillis()) }

    val categories = if (type == "INCOME") DefaultCategories.incomeCategories else DefaultCategories.expenseCategories
    var selectedCategory by remember {
        mutableStateOf(
            if (transactionToEdit != null) {
                DefaultCategories.findCategory(transactionToEdit.categoryId, transactionToEdit.type)
            } else {
                categories.first()
            }
        )
    }

    var selectedWalletId by remember {
        mutableLongStateOf(
            transactionToEdit?.walletId ?: wallets.firstOrNull()?.id ?: 0L
        )
    }

    var targetWalletId by remember {
        mutableStateOf(transactionToEdit?.targetWalletId)
    }

    var showCalcDialog by remember { mutableStateOf(false) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = if (transactionToEdit != null) "Edit Transaksi" else "Tambah Transaksi",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )

            // Type Segmented Switcher (Pengeluaran, Pemasukan, Transfer)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                val types = listOf(
                    Triple("EXPENSE", "Pengeluaran", ExpenseRed),
                    Triple("INCOME", "Pemasukan", IncomeGreen),
                    Triple("TRANSFER", "Transfer", TransferBlue)
                )
                types.forEach { (tKey, label, color) ->
                    val isSelected = type == tKey
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) color else Color.Transparent)
                            .clickable {
                                type = tKey
                                val newCats = if (tKey == "INCOME") DefaultCategories.incomeCategories else DefaultCategories.expenseCategories
                                selectedCategory = newCats.first()
                            }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            // Amount Input with Calculator shortcut
            OutlinedTextField(
                value = amountText,
                onValueChange = { amountText = it.filter { char -> char.isDigit() } },
                label = { Text("Nominal (Rp)") },
                placeholder = { Text("Contoh: 50000") },
                trailingIcon = {
                    IconButton(onClick = { showCalcDialog = true }) {
                        Icon(Icons.Default.Calculate, contentDescription = "Kalkulator", tint = PrimaryTeal)
                    }
                },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("tx_amount_input")
            )

            // Category Picker (if not Transfer)
            if (type != "TRANSFER") {
                Text("Pilih Kategori", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(categories) { cat ->
                        val isCatSelected = selectedCategory.id == cat.id
                        FilterChip(
                            selected = isCatSelected,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat.name, fontSize = 12.sp) },
                            leadingIcon = {
                                Box(modifier = Modifier.size(10.dp).background(Color(cat.color), CircleShape))
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(cat.color),
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }

            // Wallet Selection
            if (wallets.isEmpty()) {
                Text(
                    text = "⚠️ Anda belum memiliki dompet. Transaksi akan disimpan ke 'Dompet Tunai' default.",
                    style = MaterialTheme.typography.bodySmall,
                    color = WarningAmber
                )
            } else {
                Text(
                    text = if (type == "TRANSFER") "Dompet Asal" else "Pilih Dompet / Rekening",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold
                )
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(wallets) { w ->
                        val isWSelected = selectedWalletId == w.id
                        FilterChip(
                            selected = isWSelected,
                            onClick = { selectedWalletId = w.id },
                            label = { Text(w.name, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PrimaryTeal,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                if (type == "TRANSFER") {
                    Text("Dompet Tujuan", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(wallets.filter { it.id != selectedWalletId }) { w ->
                            val isTargetSelected = targetWalletId == w.id
                            FilterChip(
                                selected = isTargetSelected,
                                onClick = { targetWalletId = w.id },
                                label = { Text(w.name, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = TransferBlue,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    OutlinedTextField(
                        value = adminFeeText,
                        onValueChange = { adminFeeText = it.filter { char -> char.isDigit() } },
                        label = { Text("Biaya Admin (Opsional, Rp)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // Note Input
            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                label = { Text("Catatan / Keterangan (Opsional)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("tx_note_input")
            )

            // Submit Button
            val amount = amountText.toDoubleOrNull() ?: 0.0
            val adminFee = adminFeeText.toDoubleOrNull() ?: 0.0
            val isValid = amount > 0

            Button(
                onClick = {
                    val walletName = wallets.find { it.id == selectedWalletId }?.name ?: "Dompet Utama"
                    val targetW = wallets.find { it.id == targetWalletId }
                    onSave(
                        type,
                        amount,
                        if (type == "TRANSFER") "cat_transfer" else selectedCategory.id,
                        if (type == "TRANSFER") "Transfer Antar Dompet" else selectedCategory.name,
                        if (type == "TRANSFER") TransferBlue.value.toLong() else selectedCategory.color,
                        if (type == "TRANSFER") "swap_horiz" else selectedCategory.iconName,
                        selectedWalletId,
                        walletName,
                        targetWalletId,
                        targetW?.name,
                        adminFee,
                        note,
                        selectedDate
                    )
                },
                enabled = isValid,
                modifier = Modifier.fillMaxWidth().height(50.dp).testTag("save_tx_btn"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryTeal)
            ) {
                Text(
                    text = if (transactionToEdit != null) "Perbarui Transaksi" else "Simpan Transaksi",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }
        }
    }

    if (showCalcDialog) {
        CalculatorDialog(
            initialValue = amountText.toDoubleOrNull() ?: 0.0,
            onDismiss = { showCalcDialog = false },
            onApplyAmount = { res ->
                amountText = res.toInt().toString()
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransactionDetailBottomSheet(
    tx: TransactionEntity,
    onDismiss: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    var showDeleteConfirm by remember { mutableStateOf(false) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Detail Transaksi", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    DetailRow(label = "Tipe", value = tx.type)
                    DetailRow(label = "Kategori", value = tx.categoryName)
                    DetailRow(label = "Nominal", value = CurrencyUtils.formatRupiah(tx.amount), isHighlight = true)
                    DetailRow(label = "Dompet Asal", value = tx.walletName)
                    if (tx.targetWalletName != null) {
                        DetailRow(label = "Dompet Tujuan", value = tx.targetWalletName)
                    }
                    if (tx.adminFee > 0) {
                        DetailRow(label = "Biaya Admin", value = CurrencyUtils.formatRupiah(tx.adminFee))
                    }
                    DetailRow(label = "Waktu", value = DateUtils.formatDateTime(tx.date))
                    if (tx.note.isNotBlank()) {
                        DetailRow(label = "Catatan", value = tx.note)
                    }
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(
                    onClick = { showDeleteConfirm = true },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = ExpenseRed),
                    modifier = Modifier.weight(1f).height(48.dp)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Hapus", fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onEdit,
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryTeal),
                    modifier = Modifier.weight(1f).height(48.dp)
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Edit", fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Hapus Transaksi?", fontWeight = FontWeight.Bold) },
            text = { Text("Transaksi ini akan dihapus dan saldo akan disesuaikan kembali.") },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirm = false
                        onDelete()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed)
                ) {
                    Text("Hapus", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) { Text("Batal") }
            }
        )
    }
}

@Composable
private fun DetailRow(label: String, value: String, isHighlight: Boolean = false) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            value,
            style = if (isHighlight) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyMedium,
            fontWeight = if (isHighlight) FontWeight.Bold else FontWeight.Medium,
            color = if (isHighlight) PrimaryTeal else MaterialTheme.colorScheme.onSurface
        )
    }
}
