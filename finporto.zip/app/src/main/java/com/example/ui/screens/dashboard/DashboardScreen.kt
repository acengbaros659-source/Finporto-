package com.example.ui.screens.dashboard

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.TransactionEntity
import com.example.ui.components.DonutExpenseChart
import com.example.ui.theme.*
import com.example.ui.viewmodel.FinPortoViewModel
import com.example.ui.viewmodel.TimePeriodFilter
import com.example.util.CurrencyUtils
import com.example.util.DateUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: FinPortoViewModel,
    onNavigateToTransactions: () -> Unit,
    onNavigateToWallets: () -> Unit,
    onNavigateToPortfolios: () -> Unit,
    onNavigateToGoals: () -> Unit,
    onNavigateToAi: () -> Unit,
    onOpenCalculator: () -> Unit,
    onAddTransactionClick: () -> Unit,
    onSearchClick: () -> Unit
) {
    val dashboardState by viewModel.dashboardUiState.collectAsStateWithLifecycle()
    val userSession by viewModel.userSession.collectAsStateWithLifecycle()
    val selectedPeriod by viewModel.selectedPeriod.collectAsStateWithLifecycle()

    val userName = userSession.name.ifBlank { "Pengguna" }
    val initial = userName.firstOrNull()?.uppercaseChar()?.toString() ?: "U"

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .background(BlueContainer, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = initial,
                                fontWeight = FontWeight.ExtraBold,
                                color = OnBlueContainer,
                                fontSize = 18.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "PORTOFOLIO KEUANGAN",
                                style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.2.sp),
                                fontWeight = FontWeight.Bold,
                                color = PolishTextSecondary
                            )
                            Text(
                                text = "Halo, $userName",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = PolishTextPrimary
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = onSearchClick,
                        modifier = Modifier.testTag("global_search_btn")
                    ) {
                        Icon(
                            Icons.Default.Search,
                            contentDescription = "Cari",
                            tint = PolishTextPrimary
                        )
                    }
                    IconButton(
                        onClick = onOpenCalculator,
                        modifier = Modifier.testTag("open_calc_btn")
                    ) {
                        Icon(
                            Icons.Default.Calculate,
                            contentDescription = "Kalkulator",
                            tint = RoyalBlue
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PolishBg)
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAddTransactionClick,
                icon = { Icon(Icons.Default.Add, contentDescription = "Tambah Transaksi") },
                text = { Text("Transaksi Baru", fontWeight = FontWeight.Bold) },
                containerColor = RoyalBlue,
                contentColor = Color.White,
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.testTag("fab_add_tx")
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(PolishBg),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Period Selector Filter
            item {
                PeriodSelectorRow(
                    selectedPeriod = selectedPeriod,
                    onSelect = { viewModel.selectedPeriod.value = it }
                )
            }

            // 2. Main Saldo Card (Net Balance) with Professional Polish Royal Blue
            item {
                MainBalanceCard(
                    totalBalance = dashboardState.totalBalance,
                    totalIncome = dashboardState.totalIncome,
                    totalExpense = dashboardState.totalExpense
                )
            }

            // 3. Asset & Portfolio / Savings Summary Cards in Distinct Polish Colors
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    MiniSummaryCard(
                        modifier = Modifier.weight(1f),
                        title = "TOTAL TABUNGAN",
                        amount = dashboardState.totalSavings,
                        icon = Icons.Default.Savings,
                        cardBg = BlueCardBg,
                        textColor = BlueCardText,
                        onClick = onNavigateToGoals
                    )
                    MiniSummaryCard(
                        modifier = Modifier.weight(1f),
                        title = "TOTAL PORTOFOLIO",
                        amount = dashboardState.totalPortfolio,
                        icon = Icons.Default.TrendingUp,
                        cardBg = PurpleCardBg,
                        textColor = PurpleCardText,
                        onClick = onNavigateToPortfolios
                    )
                }
            }

            // 4. Quick Actions
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Akses Cepat",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = PolishTextPrimary
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    QuickActionButton(
                        icon = Icons.Default.AccountBalanceWallet,
                        label = "Dompet",
                        onClick = onNavigateToWallets
                    )
                    QuickActionButton(
                        icon = Icons.Default.PieChart,
                        label = "Portofolio",
                        onClick = onNavigateToPortfolios
                    )
                    QuickActionButton(
                        icon = Icons.Default.Savings,
                        label = "Target",
                        onClick = onNavigateToGoals
                    )
                    QuickActionButton(
                        icon = Icons.Default.AutoAwesome,
                        label = "Asisten AI",
                        badge = "AI",
                        onClick = onNavigateToAi
                    )
                }
            }

            // 5. Expense Breakdown by Category (Donut Chart)
            item {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = PolishSurface),
                    border = BorderStroke(1.dp, PolishBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Distribusi Pengeluaran",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = PolishTextPrimary
                            )
                            TextButton(onClick = onNavigateToTransactions) {
                                Text(
                                    "Lihat Semua",
                                    color = RoyalBlue,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        DonutExpenseChart(categories = dashboardState.topExpenseCategories)
                    }
                }
            }

            // 6. Active Budget Warnings
            if (dashboardState.activeBudgets.isNotEmpty()) {
                item {
                    Text(
                        text = "Anggaran Kategori Bulan Ini",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = PolishTextPrimary
                    )
                }
                items(dashboardState.activeBudgets) { (budget, spent) ->
                    val ratio = if (budget.limitAmount > 0) (spent / budget.limitAmount).toFloat() else 0f
                    val isExceeded = spent > budget.limitAmount
                    val isNearLimit = ratio >= 0.8f && !isExceeded

                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = when {
                                isExceeded -> ExpenseRedBg
                                isNearLimit -> WarningAmberBg
                                else -> PolishSurface
                            }
                        ),
                        border = BorderStroke(
                            1.dp,
                            when {
                                isExceeded -> ExpenseRed.copy(alpha = 0.3f)
                                isNearLimit -> WarningAmber.copy(alpha = 0.3f)
                                else -> PolishBorder
                            }
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = budget.categoryName,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = PolishTextPrimary
                                )
                                Text(
                                    text = "${CurrencyUtils.formatRupiah(spent)} / ${CurrencyUtils.formatRupiah(budget.limitAmount)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isExceeded) ExpenseRed else PolishTextPrimary
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            LinearProgressIndicator(
                                progress = { ratio.coerceIn(0f, 1f) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(CircleShape),
                                color = if (isExceeded) ExpenseRed else if (isNearLimit) WarningAmber else RoyalBlue,
                                trackColor = PolishBorder
                            )
                            if (isExceeded) {
                                Text(
                                    text = "⚠️ Pengeluaran melebihi anggaran sebesar ${CurrencyUtils.formatRupiah(spent - budget.limitAmount)}!",
                                    color = ExpenseRed,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(top = 6.dp)
                                )
                            }
                        }
                    }
                }
            }

            // 7. Recent Transactions Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Transaksi Terbaru",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = PolishTextPrimary
                    )
                    TextButton(onClick = onNavigateToTransactions) {
                        Text(
                            "Lihat Riwayat",
                            color = RoyalBlue,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Recent Transactions / Empty State
            if (dashboardState.recentTransactions.isEmpty()) {
                item {
                    Card(
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = PolishSurface),
                        border = BorderStroke(1.dp, PolishBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(72.dp)
                                    .background(PolishSurfaceVariant, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ReceiptLong,
                                    contentDescription = null,
                                    tint = PolishBorderSubtle,
                                    modifier = Modifier.size(36.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = "Belum Ada Transaksi",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = PolishTextPrimary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Klik tombol 'Transaksi Baru' untuk mencatat pemasukan atau pengeluaran pertama Anda.",
                                style = MaterialTheme.typography.bodySmall,
                                color = PolishTextSecondary,
                                fontSize = 12.sp,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = onAddTransactionClick,
                                colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                                shape = RoundedCornerShape(24.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Tambah Transaksi", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else {
                items(dashboardState.recentTransactions) { tx ->
                    RecentTransactionRow(tx = tx)
                }
            }

            // Extra padding at bottom
            item { Spacer(modifier = Modifier.height(64.dp)) }
        }
    }
}

@Composable
private fun PeriodSelectorRow(
    selectedPeriod: TimePeriodFilter,
    onSelect: (TimePeriodFilter) -> Unit
) {
    val periods = listOf(
        Pair(TimePeriodFilter.THIS_MONTH, "Bulan Ini"),
        Pair(TimePeriodFilter.THIS_WEEK, "Minggu Ini"),
        Pair(TimePeriodFilter.THIS_YEAR, "Tahun Ini"),
        Pair(TimePeriodFilter.ALL_TIME, "Semua")
    )

    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        items(periods) { (period, label) ->
            val isSelected = selectedPeriod == period
            FilterChip(
                selected = isSelected,
                onClick = { onSelect(period) },
                label = {
                    Text(
                        label,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                },
                shape = RoundedCornerShape(12.dp),
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = RoyalBlue,
                    selectedLabelColor = Color.White,
                    containerColor = PolishSurface,
                    labelColor = PolishTextSecondary
                ),
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true,
                    selected = isSelected,
                    borderColor = PolishBorder,
                    selectedBorderColor = RoyalBlue
                )
            )
        }
    }
}

@Composable
private fun MainBalanceCard(
    totalBalance: Double,
    totalIncome: Double,
    totalExpense: Double
) {
    Card(
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = RoyalBlue),
        modifier = Modifier
            .fillMaxWidth()
            .shadow(8.dp, RoundedCornerShape(28.dp))
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(RoyalBlue, RoyalBlueDark)
                    )
                )
                .padding(22.dp)
        ) {
            Column {
                Text(
                    text = "TOTAL SALDO UTAMA",
                    style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.sp),
                    fontWeight = FontWeight.Bold,
                    color = Color.White.copy(alpha = 0.85f)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = CurrencyUtils.formatRupiah(totalBalance),
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White,
                    fontSize = 32.sp
                )

                Spacer(modifier = Modifier.height(18.dp))

                // Translucent stats container
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White.copy(alpha = 0.15f), RoundedCornerShape(18.dp))
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Income
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .background(Color.White.copy(alpha = 0.2f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.AutoMirrored.Filled.TrendingUp,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    "Pemasukan",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White.copy(alpha = 0.8f)
                                )
                                Text(
                                    text = CurrencyUtils.formatRupiah(totalIncome),
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }

                        // Expense
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .background(Color.White.copy(alpha = 0.2f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.AutoMirrored.Filled.TrendingDown,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    "Pengeluaran",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White.copy(alpha = 0.8f)
                                )
                                Text(
                                    text = CurrencyUtils.formatRupiah(totalExpense),
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MiniSummaryCard(
    modifier: Modifier,
    title: String,
    amount: Double,
    icon: ImageVector,
    cardBg: Color,
    textColor: Color,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = cardBg),
        modifier = modifier
            .clickable { onClick() }
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(Color.White.copy(alpha = 0.6f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = textColor, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 0.8.sp),
                fontWeight = FontWeight.Bold,
                color = textColor.copy(alpha = 0.75f)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = CurrencyUtils.formatRupiah(amount),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                color = textColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun QuickActionButton(
    icon: ImageVector,
    label: String,
    badge: String? = null,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable { onClick() }
            .padding(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(54.dp)
                .background(BlueContainer.copy(alpha = 0.5f), RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                icon,
                contentDescription = label,
                tint = RoyalBlue,
                modifier = Modifier.size(26.dp)
            )
            if (badge != null) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .background(CatShopping, CircleShape)
                        .padding(horizontal = 5.dp, vertical = 2.dp)
                ) {
                    Text(badge, color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold,
            color = PolishTextPrimary
        )
    }
}

@Composable
private fun RecentTransactionRow(tx: TransactionEntity) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = PolishSurface),
        border = BorderStroke(1.dp, PolishBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val isIncome = tx.type == "INCOME"
            val isTransfer = tx.type == "TRANSFER"

            val iconBg = when {
                isTransfer -> TransferBlueBg
                isIncome -> IncomeGreenBg
                else -> Color(tx.categoryColor).copy(alpha = 0.15f)
            }

            val iconColor = when {
                isTransfer -> TransferBlue
                isIncome -> IncomeGreen
                else -> Color(tx.categoryColor)
            }

            Box(
                modifier = Modifier
                    .size(42.dp)
                    .background(iconBg, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when {
                        isTransfer -> Icons.Default.SwapHoriz
                        isIncome -> Icons.AutoMirrored.Filled.TrendingUp
                        else -> Icons.Default.Category
                    },
                    contentDescription = null,
                    tint = iconColor,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = tx.categoryName,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = PolishTextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "${tx.walletName}${if (tx.targetWalletName != null) " → ${tx.targetWalletName}" else ""} • ${DateUtils.formatDate(tx.date)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = PolishTextSecondary,
                    fontSize = 11.sp
                )
            }

            Text(
                text = "${if (isIncome) "+" else if (isTransfer) "" else "-"}${CurrencyUtils.formatRupiah(tx.amount)}",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = when {
                    isTransfer -> TransferBlue
                    isIncome -> IncomeGreen
                    else -> ExpenseRed
                }
            )
        }
    }
}
