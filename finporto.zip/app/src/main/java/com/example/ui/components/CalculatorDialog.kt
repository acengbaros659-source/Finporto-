package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.PrimaryTeal
import com.example.ui.theme.Slate800
import com.example.ui.theme.SlateNavy
import com.example.util.CurrencyUtils
import java.text.DecimalFormat
import kotlin.math.pow

@Composable
fun CalculatorDialog(
    initialValue: Double = 0.0,
    onDismiss: () -> Unit,
    onApplyAmount: (Double) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Standard, 1: Bunga Majemuk

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Kalkulator Keuangan",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Tutup")
                    }
                }

                // Tab Selector
                TabRow(
                    selectedTabIndex = selectedTab,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    containerColor = Color.Transparent
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("Standar (+ - × ÷ %)") }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("Simulasi Investasi") }
                    )
                }

                if (selectedTab == 0) {
                    StandardCalculatorView(
                        initialValue = initialValue,
                        onApply = { result ->
                            onApplyAmount(result)
                            onDismiss()
                        }
                    )
                } else {
                    CompoundInterestCalculatorView(
                        onApply = { result ->
                            onApplyAmount(result)
                            onDismiss()
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun StandardCalculatorView(
    initialValue: Double,
    onApply: (Double) -> Unit
) {
    var expression by remember { mutableStateOf(if (initialValue > 0) initialValue.toInt().toString() else "") }
    var resultText by remember { mutableStateOf(if (initialValue > 0) CurrencyUtils.formatRupiah(initialValue) else "0") }

    fun calculateResult(): Double {
        if (expression.isBlank()) return 0.0
        return try {
            val sanitized = expression.replace("×", "*").replace("÷", "/")
            // Simple expression evaluator
            evalSimpleMath(sanitized)
        } catch (e: Exception) {
            0.0
        }
    }

    fun onKey(key: String) {
        when (key) {
            "C" -> {
                expression = ""
                resultText = "0"
            }
            "DEL" -> {
                if (expression.isNotEmpty()) {
                    expression = expression.dropLast(1)
                    val res = calculateResult()
                    resultText = CurrencyUtils.formatRupiah(res)
                }
            }
            "=" -> {
                val res = calculateResult()
                expression = if (res % 1.0 == 0.0) res.toLong().toString() else res.toString()
                resultText = CurrencyUtils.formatRupiah(res)
            }
            "%" -> {
                val res = calculateResult() / 100.0
                expression = if (res % 1.0 == 0.0) res.toLong().toString() else res.toString()
                resultText = CurrencyUtils.formatRupiah(res)
            }
            "+", "-", "×", "÷" -> {
                if (expression.isNotEmpty() && !expression.last().isDigit() && expression.last() != '.') {
                    expression = expression.dropLast(1) + key
                } else if (expression.isNotEmpty()) {
                    expression += key
                }
            }
            else -> {
                expression += key
                val res = calculateResult()
                resultText = CurrencyUtils.formatRupiah(res)
            }
        }
    }

    Column(modifier = Modifier.fillMaxWidth()) {
        // Display
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(12.dp),
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = expression.ifBlank { "0" },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = resultText,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = PrimaryTeal,
                    maxLines = 1
                )
            }
        }

        // Keypad
        val rows = listOf(
            listOf("C", "÷", "×", "DEL"),
            listOf("7", "8", "9", "-"),
            listOf("4", "5", "6", "+"),
            listOf("1", "2", "3", "%"),
            listOf("0", "000", ".", "=")
        )

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            for (row in rows) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    for (btn in row) {
                        val isOp = btn in listOf("÷", "×", "-", "+", "=", "%")
                        val isSpecial = btn in listOf("C", "DEL")

                        val btnColor = when {
                            btn == "=" -> PrimaryTeal
                            isOp -> MaterialTheme.colorScheme.primaryContainer
                            isSpecial -> MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f)
                            else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
                        }

                        val textColor = when {
                            btn == "=" -> Color.White
                            isOp -> MaterialTheme.colorScheme.onPrimaryContainer
                            isSpecial -> MaterialTheme.colorScheme.error
                            else -> MaterialTheme.colorScheme.onSurface
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(btnColor)
                                .clickable { onKey(btn) }
                                .testTag("calc_btn_$btn"),
                            contentAlignment = Alignment.Center
                        ) {
                            if (btn == "DEL") {
                                Icon(Icons.Default.Backspace, contentDescription = "Delete", tint = textColor, modifier = Modifier.size(18.dp))
                            } else {
                                Text(
                                    text = btn,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = textColor
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Apply Button
        Button(
            onClick = {
                val finalAmt = calculateResult()
                onApply(finalAmt)
            },
            modifier = Modifier.fillMaxWidth().testTag("apply_calc_btn"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = PrimaryTeal)
        ) {
            Text("Gunakan Hasil Nominal", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun CompoundInterestCalculatorView(
    onApply: (Double) -> Unit
) {
    var initialDeposit by remember { mutableStateOf("1000000") }
    var monthlyDeposit by remember { mutableStateOf("500000") }
    var returnRate by remember { mutableStateOf("8") } // % per year
    var durationYears by remember { mutableStateOf("5") }

    val initial = initialDeposit.toDoubleOrNull() ?: 0.0
    val monthly = monthlyDeposit.toDoubleOrNull() ?: 0.0
    val rate = (returnRate.toDoubleOrNull() ?: 0.0) / 100.0 / 12.0
    val months = (durationYears.toIntOrNull() ?: 0) * 12

    // Compound interest formula: A = P(1+r)^n + PMT * [((1+r)^n - 1) / r]
    val futureValue = if (months > 0) {
        val pPart = initial * (1 + rate).pow(months)
        val pmtPart = if (rate > 0) monthly * (((1 + rate).pow(months) - 1) / rate) else monthly * months
        pPart + pmtPart
    } else {
        initial
    }

    val totalInvested = initial + (monthly * months)
    val totalGain = (futureValue - totalInvested).coerceAtLeast(0.0)

    Column(modifier = Modifier.fillMaxWidth().padding(top = 4.dp)) {
        OutlinedTextField(
            value = initialDeposit,
            onValueChange = { initialDeposit = it.filter { char -> char.isDigit() } },
            label = { Text("Modal Awal (Rp)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Spacer(modifier = Modifier.height(6.dp))

        OutlinedTextField(
            value = monthlyDeposit,
            onValueChange = { monthlyDeposit = it.filter { char -> char.isDigit() } },
            label = { Text("Setoran Rutin Bulanan (Rp)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Spacer(modifier = Modifier.height(6.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = returnRate,
                onValueChange = { returnRate = it },
                label = { Text("Estimasi Return /th (%)") },
                modifier = Modifier.weight(1f),
                singleLine = true
            )
            OutlinedTextField(
                value = durationYears,
                onValueChange = { durationYears = it.filter { char -> char.isDigit() } },
                label = { Text("Jangka Waktu (Tahun)") },
                modifier = Modifier.weight(1f),
                singleLine = true
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Result Card
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "Estimasi Nilai Akhir:",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Text(
                    text = CurrencyUtils.formatRupiah(futureValue),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = PrimaryTeal
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(
                        text = "Total Modal: ${CurrencyUtils.formatRupiah(totalInvested)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Keuntungan: +${CurrencyUtils.formatRupiah(totalGain)}",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryTeal
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Button(
            onClick = { onApply(futureValue) },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = PrimaryTeal)
        ) {
            Text("Gunakan Estimasi Nilai", fontWeight = FontWeight.Bold)
        }
    }
}

// Simple arithmetic evaluator supporting +, -, *, /, %
private fun evalSimpleMath(expression: String): Double {
    if (expression.isBlank()) return 0.0
    val tokens = mutableListOf<String>()
    var currentNumber = StringBuilder()

    for (i in expression.indices) {
        val c = expression[i]
        if (c.isDigit() || c == '.') {
            currentNumber.append(c)
        } else if (c in listOf('+', '-', '*', '/')) {
            if (currentNumber.isNotEmpty()) {
                tokens.add(currentNumber.toString())
                currentNumber = StringBuilder()
            }
            tokens.add(c.toString())
        }
    }
    if (currentNumber.isNotEmpty()) {
        tokens.add(currentNumber.toString())
    }

    if (tokens.isEmpty()) return 0.0

    // First pass for * and /
    val postMulDiv = mutableListOf<String>()
    var i = 0
    while (i < tokens.size) {
        val token = tokens[i]
        if (token == "*" || token == "/") {
            val prev = postMulDiv.removeAt(postMulDiv.size - 1).toDoubleOrNull() ?: 0.0
            val next = tokens.getOrNull(i + 1)?.toDoubleOrNull() ?: 1.0
            val result = if (token == "*") prev * next else if (next != 0.0) prev / next else 0.0
            postMulDiv.add(result.toString())
            i += 2
        } else {
            postMulDiv.add(token)
            i++
        }
    }

    // Second pass for + and -
    if (postMulDiv.isEmpty()) return 0.0
    var total = postMulDiv[0].toDoubleOrNull() ?: 0.0
    var j = 1
    while (j < postMulDiv.size) {
        val op = postMulDiv[j]
        val nextVal = postMulDiv.getOrNull(j + 1)?.toDoubleOrNull() ?: 0.0
        if (op == "+") total += nextVal
        else if (op == "-") total -= nextVal
        j += 2
    }

    return total
}
