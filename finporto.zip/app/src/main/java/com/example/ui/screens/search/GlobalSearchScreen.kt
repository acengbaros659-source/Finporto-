package com.example.ui.screens.search

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.PrimaryTeal
import com.example.ui.viewmodel.FinPortoViewModel
import com.example.util.CurrencyUtils
import com.example.util.DateUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GlobalSearchScreen(
    viewModel: FinPortoViewModel,
    onBack: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    val allTransactions by viewModel.allTransactions.collectAsStateWithLifecycle()
    val allWallets by viewModel.allWallets.collectAsStateWithLifecycle()
    val allPortfolios by viewModel.allPortfolios.collectAsStateWithLifecycle()
    val allGoals by viewModel.allSavingGoals.collectAsStateWithLifecycle()
    val allNotes by viewModel.allNotes.collectAsStateWithLifecycle()

    val matchedTransactions = remember(query, allTransactions) {
        if (query.isBlank()) emptyList()
        else allTransactions.filter {
            it.note.contains(query, ignoreCase = true) ||
            it.categoryName.contains(query, ignoreCase = true) ||
            it.walletName.contains(query, ignoreCase = true)
        }
    }

    val matchedWallets = remember(query, allWallets) {
        if (query.isBlank()) emptyList()
        else allWallets.filter { it.name.contains(query, ignoreCase = true) || it.accountNumber.contains(query, ignoreCase = true) }
    }

    val matchedPortfolios = remember(query, allPortfolios) {
        if (query.isBlank()) emptyList()
        else allPortfolios.filter { it.name.contains(query, ignoreCase = true) || it.notes.contains(query, ignoreCase = true) }
    }

    val matchedGoals = remember(query, allGoals) {
        if (query.isBlank()) emptyList()
        else allGoals.filter { it.title.contains(query, ignoreCase = true) }
    }

    val matchedNotes = remember(query, allNotes) {
        if (query.isBlank()) emptyList()
        else allNotes.filter { it.title.contains(query, ignoreCase = true) || it.content.contains(query, ignoreCase = true) }
    }

    val hasResults = matchedTransactions.isNotEmpty() || matchedWallets.isNotEmpty() ||
            matchedPortfolios.isNotEmpty() || matchedGoals.isNotEmpty() || matchedNotes.isNotEmpty()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        placeholder = { Text("Cari transaksi, dompet, aset, catatan...") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("search_field_input"),
                        shape = RoundedCornerShape(12.dp),
                        trailingIcon = {
                            if (query.isNotEmpty()) {
                                IconButton(onClick = { query = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Hapus")
                                }
                            }
                        }
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            if (query.isBlank()) {
                Box(modifier = Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text(
                        "Ketik kata kunci untuk mencari seluruh data keuangan Anda.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else if (!hasResults) {
                Box(modifier = Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text(
                        "Tidak ditemukan data untuk '$query'.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Transaksi
                    if (matchedTransactions.isNotEmpty()) {
                        item { Text("Transaksi (${matchedTransactions.size})", fontWeight = FontWeight.Bold) }
                        items(matchedTransactions) { tx ->
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(modifier = Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Column {
                                        Text(tx.categoryName, fontWeight = FontWeight.SemiBold)
                                        if (tx.note.isNotBlank()) Text(tx.note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(DateUtils.formatDate(tx.date), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Text(CurrencyUtils.formatRupiah(tx.amount), fontWeight = FontWeight.Bold, color = PrimaryTeal)
                                }
                            }
                        }
                    }

                    // Dompet
                    if (matchedWallets.isNotEmpty()) {
                        item { Text("Dompet & Rekening (${matchedWallets.size})", fontWeight = FontWeight.Bold) }
                        items(matchedWallets) { w ->
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(modifier = Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(w.name, fontWeight = FontWeight.SemiBold)
                                    Text(CurrencyUtils.formatRupiah(w.initialBalance), fontWeight = FontWeight.Bold, color = PrimaryTeal)
                                }
                            }
                        }
                    }

                    // Portofolio
                    if (matchedPortfolios.isNotEmpty()) {
                        item { Text("Portofolio (${matchedPortfolios.size})", fontWeight = FontWeight.Bold) }
                        items(matchedPortfolios) { p ->
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(modifier = Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(p.name, fontWeight = FontWeight.SemiBold)
                                    Text(CurrencyUtils.formatRupiah(p.currentValue), fontWeight = FontWeight.Bold, color = PrimaryTeal)
                                }
                            }
                        }
                    }

                    // Catatan
                    if (matchedNotes.isNotEmpty()) {
                        item { Text("Catatan (${matchedNotes.size})", fontWeight = FontWeight.Bold) }
                        items(matchedNotes) { n ->
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(n.title, fontWeight = FontWeight.SemiBold)
                                    if (n.content.isNotBlank()) Text(n.content, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
