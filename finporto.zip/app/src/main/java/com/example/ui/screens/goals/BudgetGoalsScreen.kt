package com.example.ui.screens.goals

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.BudgetEntity
import com.example.data.local.entity.SavingGoalEntity
import com.example.data.model.DefaultCategories
import com.example.ui.theme.*
import com.example.ui.viewmodel.FinPortoViewModel
import com.example.util.CurrencyUtils
import com.example.util.DateUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BudgetGoalsScreen(
    viewModel: FinPortoViewModel,
    onBack: (() -> Unit)? = null
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Saving Goals, 1: Budgets
    val savingGoals by viewModel.allSavingGoals.collectAsStateWithLifecycle()
    val budgets by viewModel.allBudgets.collectAsStateWithLifecycle()
    val wallets by viewModel.allWallets.collectAsStateWithLifecycle()
    val dashboardState by viewModel.dashboardUiState.collectAsStateWithLifecycle()

    var showAddGoalDialog by remember { mutableStateOf(false) }
    var showAddBudgetDialog by remember { mutableStateOf(false) }
    var selectedGoalForDeposit by remember { mutableStateOf<SavingGoalEntity?>(null) }
    var goalToDelete by remember { mutableStateOf<SavingGoalEntity?>(null) }
    var budgetToDelete by remember { mutableStateOf<BudgetEntity?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Target & Anggaran", fontWeight = FontWeight.Bold, color = PolishTextPrimary) },
                navigationIcon = {
                    if (onBack != null) {
                        IconButton(onClick = onBack) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Kembali", tint = PolishTextPrimary)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PolishBg)
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    if (selectedTab == 0) showAddGoalDialog = true
                    else showAddBudgetDialog = true
                },
                containerColor = RoyalBlue,
                contentColor = Color.White,
                icon = { Icon(Icons.Default.Add, contentDescription = "Tambah") },
                text = { Text(if (selectedTab == 0) "Target Baru" else "Anggaran Baru", fontWeight = FontWeight.Bold) },
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.testTag("fab_add_goal_budget")
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(PolishBg)
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = PolishSurface,
                contentColor = RoyalBlue,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = RoyalBlue
                    )
                }
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Target Tabungan (${savingGoals.size})", fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Medium, color = if (selectedTab == 0) RoyalBlue else PolishTextSecondary) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Anggaran Bulanan (${budgets.size})", fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Medium, color = if (selectedTab == 1) RoyalBlue else PolishTextSecondary) }
                )
            }

            if (selectedTab == 0) {
                // SAVING GOALS TAB
                if (savingGoals.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxSize().padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.Savings,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                modifier = Modifier.size(56.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Belum ada target tabungan.",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Buat target impian seperti Beli Rumah, DP Mobil, Liburan, atau Dana Menikah.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = { showAddGoalDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryTeal)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Buat Target Tabungan")
                            }
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(savingGoals, key = { it.id }) { goal ->
                            SavingGoalCardItem(
                                goal = goal,
                                onAddFunds = { selectedGoalForDeposit = goal },
                                onDelete = { goalToDelete = goal }
                            )
                        }
                    }
                }
            } else {
                // BUDGETS TAB
                if (budgets.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxSize().padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.AccountBalanceWallet,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                modifier = Modifier.size(56.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Belum ada anggaran kategori.",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Batasi pengeluaran kategori bulanan agar keuangan tetap terkendali.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = { showAddBudgetDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryTeal)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Buat Anggaran Kategori")
                            }
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(dashboardState.activeBudgets) { (budget, spent) ->
                            BudgetCardItem(
                                budget = budget,
                                spent = spent,
                                onDelete = { budgetToDelete = budget }
                            )
                        }
                    }
                }
            }
        }
    }

    // Add Goal Dialog
    if (showAddGoalDialog) {
        var title by remember { mutableStateOf("") }
        var targetAmountText by remember { mutableStateOf("") }
        var notes by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddGoalDialog = false },
            title = { Text("Target Tabungan Baru", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Nama Target (e.g. Dana Liburan, Beli Laptop)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("goal_title_input")
                    )
                    OutlinedTextField(
                        value = targetAmountText,
                        onValueChange = { targetAmountText = it.filter { char -> char.isDigit() } },
                        label = { Text("Target Nominal (Rp)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("goal_target_input")
                    )
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Catatan (Opsional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                val targetAmt = targetAmountText.toDoubleOrNull() ?: 0.0
                Button(
                    onClick = {
                        viewModel.addSavingGoal(
                            title = title,
                            targetAmount = targetAmt,
                            targetDate = System.currentTimeMillis() + 30L * 24 * 3600 * 1000,
                            color = IncomeGreen.value.toLong(),
                            icon = "savings",
                            notes = notes
                        )
                        showAddGoalDialog = false
                    },
                    enabled = title.isNotBlank() && targetAmt > 0,
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryTeal),
                    modifier = Modifier.testTag("save_goal_btn")
                ) {
                    Text("Buat Target", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddGoalDialog = false }) { Text("Batal") }
            }
        )
    }

    // Add Budget Dialog
    if (showAddBudgetDialog) {
        val expenseCats = DefaultCategories.expenseCategories
        var selectedCat by remember { mutableStateOf(expenseCats.first()) }
        var limitAmountText by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddBudgetDialog = false },
            title = { Text("Anggaran Kategori Baru", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Pilih Kategori Pengeluaran:", style = MaterialTheme.typography.labelSmall)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(expenseCats) { cat ->
                            FilterChip(
                                selected = selectedCat.id == cat.id,
                                onClick = { selectedCat = cat },
                                label = { Text(cat.name, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(cat.color),
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    OutlinedTextField(
                        value = limitAmountText,
                        onValueChange = { limitAmountText = it.filter { char -> char.isDigit() } },
                        label = { Text("Batas Maksimal Bulanan (Rp)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("budget_limit_input")
                    )
                }
            },
            confirmButton = {
                val limit = limitAmountText.toDoubleOrNull() ?: 0.0
                Button(
                    onClick = {
                        viewModel.addBudget(
                            categoryId = selectedCat.id,
                            categoryName = selectedCat.name,
                            categoryColor = selectedCat.color,
                            limitAmount = limit,
                            period = "MONTHLY"
                        )
                        showAddBudgetDialog = false
                    },
                    enabled = limit > 0,
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryTeal),
                    modifier = Modifier.testTag("save_budget_btn")
                ) {
                    Text("Simpan Anggaran", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddBudgetDialog = false }) { Text("Batal") }
            }
        )
    }

    // Setor Dana ke Tabungan Dialog
    if (selectedGoalForDeposit != null) {
        val goal = selectedGoalForDeposit!!
        var depositAmountText by remember { mutableStateOf("") }
        var selectedWalletId by remember { mutableLongStateOf(wallets.firstOrNull()?.id ?: 0L) }

        AlertDialog(
            onDismissRequest = { selectedGoalForDeposit = null },
            title = { Text("Setor Tabungan: ${goal.title}", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Pilih Sumber Dompet:", style = MaterialTheme.typography.labelSmall)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(wallets) { w ->
                            FilterChip(
                                selected = selectedWalletId == w.id,
                                onClick = { selectedWalletId = w.id },
                                label = { Text(w.name, fontSize = 11.sp) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = depositAmountText,
                        onValueChange = { depositAmountText = it.filter { char -> char.isDigit() } },
                        label = { Text("Nominal Setor (Rp)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("deposit_amount_input")
                    )
                }
            },
            confirmButton = {
                val dep = depositAmountText.toDoubleOrNull() ?: 0.0
                val wallet = wallets.find { it.id == selectedWalletId }
                Button(
                    onClick = {
                        if (dep > 0 && wallet != null) {
                            viewModel.addFundsToGoal(
                                goalId = goal.id,
                                amount = dep,
                                walletId = wallet.id,
                                walletName = wallet.name,
                                note = "Setor tabungan ${goal.title}"
                            )
                        }
                        selectedGoalForDeposit = null
                    },
                    enabled = dep > 0,
                    colors = ButtonDefaults.buttonColors(containerColor = IncomeGreen),
                    modifier = Modifier.testTag("confirm_deposit_btn")
                ) {
                    Text("Setor Sekarang", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedGoalForDeposit = null }) { Text("Batal") }
            }
        )
    }

    // Delete Goal Confirm
    if (goalToDelete != null) {
        AlertDialog(
            onDismissRequest = { goalToDelete = null },
            title = { Text("Hapus Target Tabungan?", fontWeight = FontWeight.Bold) },
            text = { Text("Apakah Anda yakin ingin menghapus '${goalToDelete!!.title}'?") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteSavingGoal(goalToDelete!!)
                        goalToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed)
                ) {
                    Text("Hapus", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { goalToDelete = null }) { Text("Batal") } }
        )
    }

    // Delete Budget Confirm
    if (budgetToDelete != null) {
        AlertDialog(
            onDismissRequest = { budgetToDelete = null },
            title = { Text("Hapus Anggaran?", fontWeight = FontWeight.Bold) },
            text = { Text("Apakah Anda yakin ingin menghapus anggaran '${budgetToDelete!!.categoryName}'?") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteBudget(budgetToDelete!!)
                        budgetToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed)
                ) {
                    Text("Hapus", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { budgetToDelete = null }) { Text("Batal") } }
        )
    }
}

@Composable
private fun SavingGoalCardItem(
    goal: SavingGoalEntity,
    onAddFunds: () -> Unit,
    onDelete: () -> Unit
) {
    val progress = if (goal.targetAmount > 0) (goal.currentAmount / goal.targetAmount).toFloat() else 0f
    val percentInt = (progress * 100).toInt()
    val remaining = (goal.targetAmount - goal.currentAmount).coerceAtLeast(0.0)

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier.size(40.dp).background(IncomeGreen.copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Savings, contentDescription = null, tint = IncomeGreen, modifier = Modifier.size(22.dp))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(goal.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(
                            text = if (goal.isCompleted) "🎉 Target Tercapai!" else "Sisa ${CurrencyUtils.formatRupiah(remaining)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (goal.isCompleted) IncomeGreen else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Progress bar
            LinearProgressIndicator(
                progress = { progress.coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
                color = if (goal.isCompleted) IncomeGreen else PrimaryTeal,
                trackColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${CurrencyUtils.formatRupiah(goal.currentAmount)} / ${CurrencyUtils.formatRupiah(goal.targetAmount)} ($percentInt%)",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = PrimaryTeal
                )

                Button(
                    onClick = onAddFunds,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryTeal)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Setor Dana", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun BudgetCardItem(
    budget: BudgetEntity,
    spent: Double,
    onDelete: () -> Unit
) {
    val ratio = if (budget.limitAmount > 0) (spent / budget.limitAmount).toFloat() else 0f
    val isExceeded = spent > budget.limitAmount
    val isNearLimit = ratio >= 0.8f && !isExceeded
    val remaining = (budget.limitAmount - spent).coerceAtLeast(0.0)

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = when {
                isExceeded -> ExpenseRedBg
                isNearLimit -> WarningAmberBg
                else -> MaterialTheme.colorScheme.surface
            }
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(12.dp).background(Color(budget.categoryColor), CircleShape))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(budget.categoryName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            LinearProgressIndicator(
                progress = { ratio.coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
                color = if (isExceeded) ExpenseRed else if (isNearLimit) WarningAmber else PrimaryTeal,
                trackColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Terpakai: ${CurrencyUtils.formatRupiah(spent)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isExceeded) ExpenseRed else MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = if (isExceeded) "Overbudget ${CurrencyUtils.formatRupiah(spent - budget.limitAmount)}" else "Sisa ${CurrencyUtils.formatRupiah(remaining)}",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    color = if (isExceeded) ExpenseRed else PrimaryTeal
                )
            }
        }
    }
}
