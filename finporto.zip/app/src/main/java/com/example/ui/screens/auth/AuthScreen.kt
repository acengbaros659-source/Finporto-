package com.example.ui.screens.auth

import android.app.Activity
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.security.AuthUser
import com.example.data.security.GoogleAuthHelper
import com.example.ui.theme.*
import com.example.ui.viewmodel.FinPortoViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthScreen(
    viewModel: FinPortoViewModel,
    onLoginSuccess: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val googleAuthHelper = remember { GoogleAuthHelper(context) }

    var isLoading by remember { mutableStateOf(false) }
    var loadingStatusText by remember { mutableStateOf("Menghubungkan ke Google...") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    var showAccountPickerDialog by remember { mutableStateOf(false) }
    var showCustomGoogleAccountDialog by remember { mutableStateOf(false) }
    var customGoogleEmail by remember { mutableStateOf("") }
    var customGoogleName by remember { mutableStateOf("") }

    // Primary detected Google account (Ready for 1-Tap Login like Free Fire)
    val primaryGoogleAccount = remember { googleAuthHelper.defaultGoogleAccounts.first() }

    fun proceedWithGoogleUser(user: AuthUser) {
        scope.launch {
            isLoading = true
            loadingStatusText = "Masuk sebagai ${user.name}..."
            delay(400) // smooth visual feedback
            viewModel.loginUser(
                userId = user.id,
                name = user.name,
                email = user.email,
                isGoogle = true
            )
            isLoading = false
            onLoginSuccess()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(PolishBg)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            contentPadding = PaddingValues(top = 40.dp, bottom = 40.dp)
        ) {
            item {
                // App Logo & Header
                Box(
                    modifier = Modifier
                        .size(84.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(RoyalBlue),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.app_icon_finporto),
                        contentDescription = "FinPorto Logo",
                        modifier = Modifier
                            .size(84.dp)
                            .clip(RoundedCornerShape(22.dp))
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "FinPorto",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = PolishTextPrimary
                )

                Text(
                    text = "Portofolio Keuangan & Manajemen Kas",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = RoyalBlue
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Masuk cepat dengan akun Google Anda tanpa perlu mengetik manual.",
                    style = MaterialTheme.typography.bodySmall,
                    color = PolishTextSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )

                Spacer(modifier = Modifier.height(28.dp))
            }

            // --- 1-TAP DIRECT GOOGLE ACCOUNT CARD (GAME STYLE - FREE FIRE / PLAY GAMES) ---
            item {
                Text(
                    text = "AKUN GOOGLE TERSEDIA",
                    style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.2.sp),
                    fontWeight = FontWeight.Bold,
                    color = PolishTextSecondary,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                )

                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = PolishSurface),
                    border = BorderStroke(1.5.dp, RoyalBlue.copy(alpha = 0.4f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(4.dp, RoundedCornerShape(20.dp))
                        .clickable(enabled = !isLoading) {
                            proceedWithGoogleUser(primaryGoogleAccount)
                        }
                        .testTag("one_tap_google_card")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Avatar with Google Icon Badge
                        Box(modifier = Modifier.size(54.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .background(BlueContainer, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = primaryGoogleAccount.name.firstOrNull()?.uppercase() ?: "G",
                                    fontWeight = FontWeight.ExtraBold,
                                    color = OnBlueContainer,
                                    fontSize = 20.sp
                                )
                            }
                            // Google 'G' Logo Badge on corner
                            Box(
                                modifier = Modifier
                                    .size(22.dp)
                                    .align(Alignment.BottomEnd)
                                    .background(Color.White, CircleShape)
                                    .shadow(2.dp, CircleShape)
                                    .padding(2.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.ic_google_logo),
                                    contentDescription = "Google",
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = primaryGoogleAccount.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = PolishTextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    color = IncomeGreenBg,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = "Siap",
                                        color = IncomeGreen,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = primaryGoogleAccount.email,
                                style = MaterialTheme.typography.bodySmall,
                                color = PolishTextSecondary,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Klik untuk langsung masuk (1-Tap)",
                                style = MaterialTheme.typography.labelSmall,
                                color = RoyalBlue,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }

                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "Masuk",
                            tint = RoyalBlue,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }

            // --- OFFICIAL GOOGLE SIGN-IN BUTTON ---
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = PolishSurface),
                    border = BorderStroke(1.dp, PolishBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(2.dp, RoundedCornerShape(16.dp))
                        .clickable(enabled = !isLoading) {
                            scope.launch {
                                isLoading = true
                                loadingStatusText = "Membuka Google OAuth..."
                                val result = googleAuthHelper.signInWithGoogle(context as Activity)
                                result.fold(
                                    onSuccess = { user ->
                                        proceedWithGoogleUser(user)
                                    },
                                    onFailure = {
                                        isLoading = false
                                        showAccountPickerDialog = true
                                    }
                                )
                            }
                        }
                        .testTag("google_login_official_btn")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_google_logo),
                            contentDescription = "Logo Google",
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Lanjutkan dengan Akun Google",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = PolishTextPrimary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Switch / Choose another Google account
                TextButton(
                    onClick = { showAccountPickerDialog = true },
                    modifier = Modifier.testTag("switch_google_account_btn")
                ) {
                    Icon(
                        Icons.Default.SwitchAccount,
                        contentDescription = null,
                        tint = RoyalBlue,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Pilih Akun Google Lain / Tambah Akun",
                        color = RoyalBlue,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))
            }

            // --- LOADING INDICATOR ---
            if (isLoading) {
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = BlueCardBg),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(24.dp),
                                color = RoyalBlue,
                                strokeWidth = 3.dp
                            )
                            Spacer(modifier = Modifier.width(14.dp))
                            Text(
                                text = loadingStatusText,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = BlueCardText
                            )
                        }
                    }
                }
            }

            // --- ERROR MESSAGE ---
            if (errorMessage != null) {
                item {
                    Text(
                        text = errorMessage!!,
                        color = ExpenseRed,
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }
            }

            // --- SECURITY HIGHLIGHTS (100% PRIVATE & CLEAN) ---
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = PolishSurface),
                    border = BorderStroke(1.dp, PolishBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        SecurityFeatureItem(
                            icon = Icons.Default.Security,
                            title = "Isolasi Akun Google Terproteksi",
                            desc = "Data transaksi Anda tersimpan aman dan terisolasi per ID akun Google."
                        )
                        SecurityFeatureItem(
                            icon = Icons.Default.CheckCircle,
                            title = "Kondisi Awal Bersih (Rp0)",
                            desc = "Bebas dari data palsu/dummy. Mulai pencatatan keuangan murni dari nol."
                        )
                        SecurityFeatureItem(
                            icon = Icons.Default.Lock,
                            title = "Keamanan PIN & Biometrik Opsional",
                            desc = "Dapat dikunci dengan PIN 6 digit untuk proteksi privasi finansial maksimal."
                        )
                    }
                }
            }
        }
    }

    // --- GOOGLE ACCOUNT PICKER DIALOG (1-TAP ACCOUNT SELECTION) ---
    if (showAccountPickerDialog) {
        AlertDialog(
            onDismissRequest = { showAccountPickerDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_google_logo),
                        contentDescription = null,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("Pilih Akun Google", fontWeight = FontWeight.Bold, color = PolishTextPrimary)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Pilih akun Google yang ingin Anda gunakan untuk masuk ke FinPorto:",
                        style = MaterialTheme.typography.bodySmall,
                        color = PolishTextSecondary
                    )

                    // Account List
                    googleAuthHelper.defaultGoogleAccounts.forEach { account ->
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = PolishSurfaceVariant),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    showAccountPickerDialog = false
                                    proceedWithGoogleUser(account)
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .background(RoyalBlue, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = account.name.firstOrNull()?.uppercase() ?: "G",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = account.name,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = PolishTextPrimary
                                    )
                                    Text(
                                        text = account.email,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = PolishTextSecondary,
                                        fontSize = 11.sp
                                    )
                                }
                                Icon(
                                    Icons.Default.Check,
                                    contentDescription = null,
                                    tint = RoyalBlue,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    // Button to add another custom Google account
                    OutlinedButton(
                        onClick = {
                            showAccountPickerDialog = false
                            showCustomGoogleAccountDialog = true
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 6.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Gunakan Akun Google Lainnya", fontWeight = FontWeight.Bold)
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showAccountPickerDialog = false }) {
                    Text("Batal")
                }
            }
        )
    }

    // --- CUSTOM GOOGLE ACCOUNT INPUT DIALOG (IF USER WANTS SPECIFIC GOOGLE EMAIL) ---
    if (showCustomGoogleAccountDialog) {
        AlertDialog(
            onDismissRequest = { showCustomGoogleAccountDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_google_logo),
                        contentDescription = null,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("Akun Google Baru", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Masukkan info akun Google Anda untuk membuat profil portofolio baru:",
                        style = MaterialTheme.typography.bodySmall,
                        color = PolishTextSecondary
                    )
                    OutlinedTextField(
                        value = customGoogleName,
                        onValueChange = { customGoogleName = it },
                        label = { Text("Nama Akun Google") },
                        placeholder = { Text("Misal: Aceng Baros") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = customGoogleEmail,
                        onValueChange = { customGoogleEmail = it },
                        label = { Text("Alamat Email (@gmail.com)") },
                        placeholder = { Text("namaanda@gmail.com") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val name = customGoogleName.trim().ifEmpty { "Pengguna Google" }
                        val email = customGoogleEmail.trim().ifEmpty { "user@gmail.com" }
                        val cleanId = "google_${email.replace("@", "_").replace(".", "_")}"
                        showCustomGoogleAccountDialog = false
                        proceedWithGoogleUser(
                            AuthUser(
                                id = cleanId,
                                name = name,
                                email = email,
                                isGoogle = true
                            )
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Masuk Sekarang", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCustomGoogleAccountDialog = false }) {
                    Text("Batal")
                }
            }
        )
    }
}

@Composable
private fun SecurityFeatureItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    desc: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .background(BlueContainer.copy(alpha = 0.6f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = RoyalBlue,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = PolishTextPrimary
            )
            Text(
                text = desc,
                style = MaterialTheme.typography.bodySmall,
                color = PolishTextSecondary,
                fontSize = 11.sp
            )
        }
    }
}
