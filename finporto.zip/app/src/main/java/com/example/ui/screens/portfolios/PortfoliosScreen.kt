package com.example.ui.screens.portfolios

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.PortfolioEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.FinPortoViewModel
import com.example.util.CurrencyUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PortfoliosScreen(
    viewModel: FinPortoViewModel
) {
    val portfolios by viewModel.allPortfolios.collectAsStateWithLifecycle()
    var showAddDialog by remember { mutableStateOf(false) }
    var portfolioToEdit by remember { mutableStateOf<PortfolioEntity?>(null) }
    var portfolioToDelete by remember { mutableStateOf<PortfolioEntity?>(null) }

    val totalValuation = portfolios.sumOf { it.currentValue }
    val totalInvested = portfolios.sumOf { it.initialInvested }
    val totalGainLoss = totalValuation - totalInvested
    val totalGainLossPercentage = if (totalInvested > 0) ((totalGainLoss / totalInvested) * 100).toFloat() else 0f

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Portofolio & Aset", fontWeight = FontWeight.Bold, color = PolishTextPrimary) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PolishBg)
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = RoyalBlue,
                contentColor = Color.White,
                icon = { Icon(Icons.Default.Add, contentDescription = "Tambah Aset") },
                text = { Text("Aset Baru", fontWeight = FontWeight.Bold) },
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.testTag("fab_add_portfolio")
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(PolishBg)
        ) {
            if (portfolios.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize().padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.PieChart,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Belum ada portofolio atau aset.",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Catat investasi saham, reksadana, emas, properti, bisnis, atau dana darurat Anda.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { showAddDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryTeal)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Tambah Aset Pertama")
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Header Total Valuation Card
                    item {
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = SlateNavy),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(18.dp)) {
                                Text("Total Valuasi Portofolio", style = MaterialTheme.typography.labelSmall, color = Slate400)
                                Text(
                                    text = CurrencyUtils.formatRupiah(totalValuation),
                                    style = MaterialTheme.typography.headlineMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White
                                )
                                if (totalInvested > 0) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = "Modal: ${CurrencyUtils.formatRupiah(totalInvested)} • ",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Slate300
                                        )
                                        Text(
                                            text = "${if (totalGainLoss >= 0) "+" else ""}${CurrencyUtils.formatRupiah(totalGainLoss)} (${"%.1f".format(totalGainLossPercentage)}%)",
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.Bold,
                                            color = if (totalGainLoss >= 0) IncomeGreen else ExpenseRed
                                        )
                                    }
                                }
                            }
                        }
                    }

                    items(portfolios, key = { it.id }) { item ->
                        PortfolioCardItem(
                            portfolio = item,
                            onEdit = { portfolioToEdit = item },
                            onDelete = { portfolioToDelete = item }
                        )
                    }
                }
            }
        }
    }

    // Add / Edit Dialog
    if (showAddDialog || portfolioToEdit != null) {
        val isEdit = portfolioToEdit != null
        var name by remember { mutableStateOf(portfolioToEdit?.name ?: "") }
        var type by remember { mutableStateOf(portfolioToEdit?.type ?: "INVESTMENT") }
        var currentValueText by remember { mutableStateOf(portfolioToEdit?.currentValue?.toInt()?.toString() ?: "") }
        var initialInvestedText by remember { mutableStateOf(portfolioToEdit?.initialInvested?.toInt()?.toString() ?: "") }
        var notes by remember { mutableStateOf(portfolioToEdit?.notes ?: "") }
        var selectedColor by remember { mutableLongStateOf(portfolioToEdit?.color ?: InvestmentPurple.value.toLong()) }

        AlertDialog(
            onDismissRequest = {
                showAddDialog = false
                portfolioToEdit = null
            },
            title = { Text(if (isEdit) "Edit Portofolio" else "Tambah Portofolio / Aset", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Nama Aset (e.g. Saham BBCA, Reksa RDN, Emas Antam)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("portfolio_name_input")
                    )

                    // Type Chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf("INVESTMENT" to "Investasi", "EMERGENCY_FUND" to "Dana Darurat", "ASSET" to "Aset Fisik", "BUSINESS" to "Bisnis").forEach { (tKey, label) ->
                            val isSel = type == tKey
                            FilterChip(
                                selected = isSel,
                                onClick = { type = tKey },
                                label = { Text(label, fontSize = 10.sp) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = currentValueText,
                        onValueChange = { currentValueText = it.filter { char -> char.isDigit() } },
                        label = { Text("Nilai Valuasi Saat Ini (Rp)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("portfolio_value_input")
                    )

                    OutlinedTextField(
                        value = initialInvestedText,
                        onValueChange = { initialInvestedText = it.filter { char -> char.isDigit() } },
                        label = { Text("Modal Pembelian / Investasi Awal (Rp)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Catatan / Keterangan (Opsional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                val curVal = currentValueText.toDoubleOrNull() ?: 0.0
                val initVal = initialInvestedText.toDoubleOrNull() ?: 0.0
                Button(
                    onClick = {
                        if (isEdit) {
                            viewModel.updatePortfolio(
                                portfolioToEdit!!.copy(
                                    name = name,
                                    type = type,
                                    currentValue = curVal,
                                    initialInvested = initVal,
                                    notes = notes,
                                    color = selectedColor
                                )
                            )
                        } else {
                            viewModel.addPortfolio(
                                name = name,
                                type = type,
                                currentValue = curVal,
                                initialInvested = initVal,
                                targetValue = 0.0,
                                notes = notes,
                                color = selectedColor,
                                icon = "trending_up"
                            )
                        }
                        showAddDialog = false
                        portfolioToEdit = null
                    },
                    enabled = name.isNotBlank() && curVal > 0,
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryTeal),
                    modifier = Modifier.testTag("save_portfolio_btn")
                ) {
                    Text("Simpan", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showAddDialog = false
                    portfolioToEdit = null
                }) { Text("Batal") }
            }
        )
    }

    // Delete Confirmation
    if (portfolioToDelete != null) {
        AlertDialog(
            onDismissRequest = { portfolioToDelete = null },
            title = { Text("Hapus Portofolio?", fontWeight = FontWeight.Bold) },
            text = { Text("Apakah Anda yakin ingin menghapus '${portfolioToDelete!!.name}'?") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deletePortfolio(portfolioToDelete!!)
                        portfolioToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed)
                ) {
                    Text("Hapus", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { portfolioToDelete = null }) { Text("Batal") }
            }
        )
    }
}

@Composable
private fun PortfolioCardItem(
    portfolio: PortfolioEntity,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val gainLoss = portfolio.currentValue - portfolio.initialInvested
    val gainLossPercent = if (portfolio.initialInvested > 0) ((gainLoss / portfolio.initialInvested) * 100).toFloat() else 0f

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .background(InvestmentPurple.copy(alpha = 0.15f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.TrendingUp,
                    contentDescription = null,
                    tint = InvestmentPurple,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(portfolio.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    text = portfolio.type,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = CurrencyUtils.formatRupiah(portfolio.currentValue),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                if (portfolio.initialInvested > 0) {
                    Text(
                        text = "Modal ${CurrencyUtils.formatRupiah(portfolio.initialInvested)} • ${if (gainLoss >= 0) "+" else ""}${"%.1f".format(gainLossPercent)}%",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = if (gainLoss >= 0) IncomeGreen else ExpenseRed
                    )
                }
            }

            IconButton(onClick = onEdit) {
                Icon(Icons.Default.Edit, contentDescription = "Edit", tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = ExpenseRed)
            }
        }
    }
}
