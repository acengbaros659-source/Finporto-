package com.example.ui.screens.wallets

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.WalletEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.FinPortoViewModel
import com.example.util.CurrencyUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WalletsScreen(
    viewModel: FinPortoViewModel
) {
    val wallets by viewModel.allWallets.collectAsStateWithLifecycle()
    var showAddDialog by remember { mutableStateOf(false) }
    var showTransferDialog by remember { mutableStateOf(false) }
    var walletToEdit by remember { mutableStateOf<WalletEntity?>(null) }
    var walletToDelete by remember { mutableStateOf<WalletEntity?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Dompet & Rekening", fontWeight = FontWeight.Bold, color = PolishTextPrimary) },
                actions = {
                    if (wallets.size >= 2) {
                        IconButton(onClick = { showTransferDialog = true }, modifier = Modifier.testTag("transfer_wallet_btn")) {
                            Icon(Icons.Default.SwapHoriz, contentDescription = "Transfer Antar Dompet", tint = RoyalBlue)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PolishBg)
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = RoyalBlue,
                contentColor = Color.White,
                icon = { Icon(Icons.Default.Add, contentDescription = "Tambah Dompet") },
                text = { Text("Dompet Baru", fontWeight = FontWeight.Bold) },
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.testTag("fab_add_wallet")
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(PolishBg)
        ) {
            if (wallets.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize().padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.AccountBalanceWallet,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Belum ada dompet atau rekening.",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Tambahkan akun Cash, Bank (BCA/Mandiri/BRI), atau E-Wallet (GoPay/OVO) Anda.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { showAddDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryTeal)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Tambah Dompet Pertama")
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(wallets, key = { it.id }) { wallet ->
                        WalletCardItem(
                            wallet = wallet,
                            onEdit = { walletToEdit = wallet },
                            onDelete = { walletToDelete = wallet }
                        )
                    }
                }
            }
        }
    }

    // Add / Edit Wallet Dialog
    if (showAddDialog || walletToEdit != null) {
        val isEdit = walletToEdit != null
        var name by remember { mutableStateOf(walletToEdit?.name ?: "") }
        var type by remember { mutableStateOf(walletToEdit?.type ?: "BANK") }
        var initialBalanceText by remember { mutableStateOf(walletToEdit?.initialBalance?.toInt()?.toString() ?: "0") }
        var accountNumber by remember { mutableStateOf(walletToEdit?.accountNumber ?: "") }
        var selectedColor by remember { mutableLongStateOf(walletToEdit?.color ?: PrimaryTeal.value.toLong()) }

        AlertDialog(
            onDismissRequest = {
                showAddDialog = false
                walletToEdit = null
            },
            title = { Text(if (isEdit) "Edit Dompet" else "Tambah Dompet Baru", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Nama Dompet (e.g. BCA, Tunai, GoPay)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("wallet_name_input")
                    )

                    // Type Picker
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("BANK" to "Bank", "EWALLET" to "E-Wallet", "CASH" to "Tunai", "OTHER" to "Lainnya").forEach { (tKey, label) ->
                            val isSel = type == tKey
                            FilterChip(
                                selected = isSel,
                                onClick = { type = tKey },
                                label = { Text(label, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = PrimaryTeal,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    if (!isEdit) {
                        OutlinedTextField(
                            value = initialBalanceText,
                            onValueChange = { initialBalanceText = it.filter { char -> char.isDigit() } },
                            label = { Text("Saldo Awal (Rp)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("wallet_balance_input")
                        )
                    }

                    OutlinedTextField(
                        value = accountNumber,
                        onValueChange = { accountNumber = it },
                        label = { Text("No. Rekening / Keterangan (Opsional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val initBal = initialBalanceText.toDoubleOrNull() ?: 0.0
                        if (isEdit) {
                            viewModel.updateWallet(
                                walletToEdit!!.copy(
                                    name = name,
                                    type = type,
                                    accountNumber = accountNumber,
                                    color = selectedColor
                                )
                            )
                        } else {
                            viewModel.addWallet(
                                name = name,
                                type = type,
                                initialBalance = initBal,
                                color = selectedColor,
                                icon = "account_balance_wallet",
                                accountNumber = accountNumber
                            )
                        }
                        showAddDialog = false
                        walletToEdit = null
                    },
                    enabled = name.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryTeal),
                    modifier = Modifier.testTag("save_wallet_btn")
                ) {
                    Text("Simpan", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showAddDialog = false
                    walletToEdit = null
                }) { Text("Batal") }
            }
        )
    }

    // Transfer Antar Dompet Dialog
    if (showTransferDialog) {
        var sourceWalletId by remember { mutableLongStateOf(wallets.firstOrNull()?.id ?: 0L) }
        var targetWalletId by remember { mutableLongStateOf(wallets.getOrNull(1)?.id ?: 0L) }
        var amountText by remember { mutableStateOf("") }
        var adminFeeText by remember { mutableStateOf("") }
        var note by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showTransferDialog = false },
            title = { Text("Transfer Antar Dompet", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Dompet Asal:", style = MaterialTheme.typography.labelSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        wallets.forEach { w ->
                            FilterChip(
                                selected = sourceWalletId == w.id,
                                onClick = {
                                    sourceWalletId = w.id
                                    if (targetWalletId == w.id) {
                                        targetWalletId = wallets.firstOrNull { it.id != w.id }?.id ?: 0L
                                    }
                                },
                                label = { Text(w.name, fontSize = 11.sp) }
                            )
                        }
                    }

                    Text("Dompet Tujuan:", style = MaterialTheme.typography.labelSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        wallets.filter { it.id != sourceWalletId }.forEach { w ->
                            FilterChip(
                                selected = targetWalletId == w.id,
                                onClick = { targetWalletId = w.id },
                                label = { Text(w.name, fontSize = 11.sp) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = amountText,
                        onValueChange = { amountText = it.filter { char -> char.isDigit() } },
                        label = { Text("Nominal Transfer (Rp)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("transfer_amount_input")
                    )

                    OutlinedTextField(
                        value = adminFeeText,
                        onValueChange = { adminFeeText = it.filter { char -> char.isDigit() } },
                        label = { Text("Biaya Admin (Opsional, Rp)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text("Catatan Transfer (Opsional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                val amt = amountText.toDoubleOrNull() ?: 0.0
                val fee = adminFeeText.toDoubleOrNull() ?: 0.0
                Button(
                    onClick = {
                        val sWallet = wallets.find { it.id == sourceWalletId }
                        val tWallet = wallets.find { it.id == targetWalletId }
                        if (sWallet != null && tWallet != null && amt > 0) {
                            viewModel.addTransaction(
                                type = "TRANSFER",
                                amount = amt,
                                categoryId = "cat_transfer",
                                categoryName = "Transfer Antar Dompet",
                                categoryColor = TransferBlue.value.toLong(),
                                categoryIcon = "swap_horiz",
                                walletId = sWallet.id,
                                walletName = sWallet.name,
                                targetWalletId = tWallet.id,
                                targetWalletName = tWallet.name,
                                adminFee = fee,
                                note = note
                            )
                        }
                        showTransferDialog = false
                    },
                    enabled = amt > 0,
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryTeal),
                    modifier = Modifier.testTag("confirm_transfer_btn")
                ) {
                    Text("Transfer Sekarang", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showTransferDialog = false }) { Text("Batal") }
            }
        )
    }

    // Delete Wallet Confirmation
    if (walletToDelete != null) {
        AlertDialog(
            onDismissRequest = { walletToDelete = null },
            title = { Text("Hapus Dompet?", fontWeight = FontWeight.Bold) },
            text = { Text("Apakah Anda yakin ingin menghapus dompet '${walletToDelete!!.name}'?") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteWallet(walletToDelete!!)
                        walletToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed)
                ) {
                    Text("Hapus", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { walletToDelete = null }) { Text("Batal") }
            }
        )
    }
}

@Composable
private fun WalletCardItem(
    wallet: WalletEntity,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(Color(wallet.color).copy(alpha = 0.15f), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when (wallet.type) {
                        "BANK" -> Icons.Default.AccountBalance
                        "EWALLET" -> Icons.Default.Smartphone
                        "CASH" -> Icons.Default.Payments
                        else -> Icons.Default.AccountBalanceWallet
                    },
                    contentDescription = null,
                    tint = Color(wallet.color),
                    modifier = Modifier.size(26.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(wallet.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    text = "${wallet.type}${if (wallet.accountNumber.isNotBlank()) " • ${wallet.accountNumber}" else ""}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = CurrencyUtils.formatRupiah(wallet.initialBalance),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = PrimaryTeal
                )
            }

            IconButton(onClick = onEdit) {
                Icon(Icons.Default.Edit, contentDescription = "Edit", tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = ExpenseRed)
            }
        }
    }
}
