package com.example.ui.screens.recurring

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.RecurringTransactionEntity
import com.example.data.model.DefaultCategories
import com.example.ui.theme.*
import com.example.ui.viewmodel.FinPortoViewModel
import com.example.util.CurrencyUtils
import com.example.util.DateUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecurringScreen(
    viewModel: FinPortoViewModel,
    onBack: (() -> Unit)? = null
) {
    val recurringList by viewModel.allRecurring.collectAsStateWithLifecycle()
    val wallets by viewModel.allWallets.collectAsStateWithLifecycle()
    var showAddDialog by remember { mutableStateOf(false) }
    var recurringToDelete by remember { mutableStateOf<RecurringTransactionEntity?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Transaksi Berulang & Tagihan", fontWeight = FontWeight.Bold, color = PolishTextPrimary) },
                navigationIcon = {
                    if (onBack != null) {
                        IconButton(onClick = onBack) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Kembali", tint = PolishTextPrimary)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PolishBg)
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = RoyalBlue,
                contentColor = Color.White,
                icon = { Icon(Icons.Default.Add, contentDescription = "Tambah Berulang") },
                text = { Text("Tagihan Baru", fontWeight = FontWeight.Bold) },
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.testTag("fab_add_recurring")
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(PolishBg)
        ) {
            if (recurringList.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize().padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.EventRepeat,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Belum ada transaksi berulang.",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Jadwalkan langganan bulanan seperti Spotify, Netflix, Listrik PLN, atau Gaji Rutin.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { showAddDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryTeal)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Tambah Pengingat Rutin")
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(recurringList, key = { it.id }) { item ->
                        RecurringCardItem(
                            item = item,
                            onToggleActive = {
                                viewModel.updateRecurring(item.copy(isActive = !item.isActive))
                            },
                            onDelete = { recurringToDelete = item }
                        )
                    }
                }
            }
        }
    }

    // Add Recurring Dialog
    if (showAddDialog) {
        var title by remember { mutableStateOf("") }
        var type by remember { mutableStateOf("EXPENSE") }
        var amountText by remember { mutableStateOf("") }
        var interval by remember { mutableStateOf("MONTHLY") }
        var selectedWalletId by remember { mutableLongStateOf(wallets.firstOrNull()?.id ?: 0L) }

        val expenseCats = DefaultCategories.expenseCategories
        var selectedCategory by remember { mutableStateOf(expenseCats.first()) }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Transaksi Berulang Baru", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Nama Tagihan / Transaksi (e.g. WiFi IndiHome)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("recurring_title_input")
                    )

                    // Interval Picker
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("MONTHLY" to "Bulanan", "WEEKLY" to "Mingguan", "YEARLY" to "Tahunan").forEach { (iKey, label) ->
                            val isSel = interval == iKey
                            FilterChip(
                                selected = isSel,
                                onClick = { interval = iKey },
                                label = { Text(label, fontSize = 11.sp) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = amountText,
                        onValueChange = { amountText = it.filter { char -> char.isDigit() } },
                        label = { Text("Nominal Rutin (Rp)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("recurring_amount_input")
                    )

                    if (wallets.isNotEmpty()) {
                        Text("Dompet Pembayaran:", style = MaterialTheme.typography.labelSmall)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(wallets) { w ->
                                FilterChip(
                                    selected = selectedWalletId == w.id,
                                    onClick = { selectedWalletId = w.id },
                                    label = { Text(w.name, fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                val amt = amountText.toDoubleOrNull() ?: 0.0
                val wallet = wallets.find { it.id == selectedWalletId }
                Button(
                    onClick = {
                        viewModel.addRecurring(
                            title = title,
                            type = type,
                            amount = amt,
                            categoryId = selectedCategory.id,
                            categoryName = selectedCategory.name,
                            walletId = selectedWalletId,
                            walletName = wallet?.name ?: "Dompet Utama",
                            interval = interval,
                            nextDueDate = System.currentTimeMillis() + 30L * 24 * 3600 * 1000,
                            note = "Tagihan rutin $interval"
                        )
                        showAddDialog = false
                    },
                    enabled = title.isNotBlank() && amt > 0,
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryTeal),
                    modifier = Modifier.testTag("save_recurring_btn")
                ) {
                    Text("Simpan", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) { Text("Batal") }
            }
        )
    }

    if (recurringToDelete != null) {
        AlertDialog(
            onDismissRequest = { recurringToDelete = null },
            title = { Text("Hapus Transaksi Berulang?", fontWeight = FontWeight.Bold) },
            text = { Text("Apakah Anda yakin ingin menghapus '${recurringToDelete!!.title}'?") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteRecurring(recurringToDelete!!)
                        recurringToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed)
                ) { Text("Hapus", fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { recurringToDelete = null }) { Text("Batal") } }
        )
    }
}

@Composable
private fun RecurringCardItem(
    item: RecurringTransactionEntity,
    onToggleActive: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(44.dp).background(PrimaryTeal.copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.EventRepeat, contentDescription = null, tint = PrimaryTeal, modifier = Modifier.size(22.dp))
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(item.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    text = "${item.interval} • ${item.walletName}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = CurrencyUtils.formatRupiah(item.amount),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = PrimaryTeal
                )
            }

            Switch(
                checked = item.isActive,
                onCheckedChange = { onToggleActive() },
                colors = SwitchDefaults.colors(checkedThumbColor = PrimaryTeal, checkedTrackColor = PrimaryTeal.copy(alpha = 0.3f))
            )

            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = ExpenseRed)
            }
        }
    }
}
