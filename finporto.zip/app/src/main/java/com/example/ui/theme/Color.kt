package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// "Professional Polish" Theme Color Palette
val RoyalBlue = Color(0xFF005AC1)
val RoyalBlueLight = Color(0xFF2170E4)
val RoyalBlueDark = Color(0xFF004394)
val BlueContainer = Color(0xFFD3E3FD)
val BlueContainerLight = Color(0xFFD1E4FF)
val OnBlueContainer = Color(0xFF041E49)
val OnBlueContainerDark = Color(0xFF001D36)

// Neutral & Surface Tones
val PolishBg = Color(0xFFFDFBFF)
val PolishSurface = Color(0xFFFFFFFF)
val PolishSurfaceVariant = Color(0xFFF2F0F4)
val PolishNavBg = Color(0xFFF3F3FA)
val PolishBorder = Color(0xFFE1E2EC)
val PolishBorderSubtle = Color(0xFFC4C6CF)

// Text Tones
val PolishTextPrimary = Color(0xFF1A1C1E)
val PolishTextSecondary = Color(0xFF44474E)
val PolishTextMuted = Color(0xFF49454F)

// Stat Card Pastel Accents
val PurpleCardBg = Color(0xFFE8DEF8)
val PurpleCardText = Color(0xFF1D1B20)
val PurpleCardSub = Color(0xFF49454F)

val BlueCardBg = Color(0xFFD1E4FF)
val BlueCardText = Color(0xFF001D36)

// Semantic Financial Indicators
val IncomeGreen = Color(0xFF00875A)
val IncomeGreenBg = Color(0xFFE6F4EA)
val ExpenseRed = Color(0xFFBA1A1A)
val ExpenseRedBg = Color(0xFFFFDAD6)
val TransferBlue = Color(0xFF005AC1)
val TransferBlueBg = Color(0xFFD1E4FF)
val InvestmentPurple = Color(0xFF6750A4)
val InvestmentPurpleBg = Color(0xFFE8DEF8)
val WarningAmber = Color(0xFFE28400)
val WarningAmberBg = Color(0xFFFFF3E0)

// Backward-compatible alias variables
val PrimaryTeal = RoyalBlue
val PrimaryTealLight = RoyalBlueLight
val PrimaryTealDark = RoyalBlueDark
val PrimaryTealContainer = BlueContainer
val OnPrimaryTealContainer = OnBlueContainer

val SlateNavy = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate500 = Color(0xFF64748B)
val Slate400 = Color(0xFF94A3B8)
val Slate300 = Color(0xFFCBD5E1)
val Slate200 = Color(0xFFE2E8F0)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)

// Category Distinct Colors
val CatFood = Color(0xFFEA580C)
val CatTransport = Color(0xFF0284C7)
val CatSalary = Color(0xFF16A34A)
val CatShopping = Color(0xFFDB2777)
val CatBills = Color(0xFFDC2626)
val CatHealth = Color(0xFF0D9488)
val CatEducation = Color(0xFF4F46E5)
val CatEntertainment = Color(0xFF7C3AED)
val CatInvestment = Color(0xFF005AC1)
val CatBonus = Color(0xFFD97706)
val CatFreelance = Color(0xFF0369A1)
val CatInternet = Color(0xFF475569)
val CatOther = Color(0xFF64748B)
