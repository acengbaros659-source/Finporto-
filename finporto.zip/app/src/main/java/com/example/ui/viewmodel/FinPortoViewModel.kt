package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.GeminiService
import com.example.data.local.FinPortoDatabase
import com.example.data.local.entity.*
import com.example.data.repository.*
import com.example.data.security.SessionManager
import com.example.data.security.UserSession
import com.example.util.DateUtils
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Calendar

enum class TimePeriodFilter {
    THIS_MONTH, THIS_WEEK, THIS_YEAR, ALL_TIME, CUSTOM
}

enum class TransactionSortOption {
    DATE_DESC, DATE_ASC, AMOUNT_DESC, AMOUNT_ASC
}

data class DashboardUiState(
    val totalBalance: Double = 0.0,
    val totalIncome: Double = 0.0,
    val totalExpense: Double = 0.0,
    val totalSavings: Double = 0.0,
    val totalPortfolio: Double = 0.0,
    val recentTransactions: List<TransactionEntity> = emptyList(),
    val topExpenseCategories: List<CategorySpendSummary> = emptyList(),
    val monthlyBars: List<MonthlyBarData> = emptyList(),
    val balanceTrend: List<Pair<String, Double>> = emptyList(),
    val activeBudgets: List<Pair<BudgetEntity, Double>> = emptyList(),
    val activeSavingGoals: List<SavingGoalEntity> = emptyList()
)

data class AiAssistantUiState(
    val isLoading: Boolean = false,
    val analysisText: String = "",
    val errorMessage: String = "",
    val lastUpdated: Long = 0
)

class FinPortoViewModel(application: Application) : AndroidViewModel(application) {
    private val db = FinPortoDatabase.getInstance(application)
    val repository = FinPortoRepository(db)
    val sessionManager = SessionManager(application)
    val geminiService = GeminiService()

    val userSession: StateFlow<UserSession> = sessionManager.userSessionFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserSession())

    // Filter states
    val selectedPeriod = MutableStateFlow(TimePeriodFilter.THIS_MONTH)
    val transactionSearchQuery = MutableStateFlow("")
    val selectedTypeFilter = MutableStateFlow<String?>("ALL") // "ALL", "INCOME", "EXPENSE", "TRANSFER"
    val selectedCategoryFilter = MutableStateFlow<String?>(null)
    val selectedWalletFilter = MutableStateFlow<Long?>(null)
    val transactionSort = MutableStateFlow(TransactionSortOption.DATE_DESC)

    // UI Feedback Message
    val userMessage = MutableStateFlow<String?>(null)

    // AI Assistant State
    val aiState = MutableStateFlow(AiAssistantUiState())

    // All active user entities
    @OptIn(ExperimentalCoroutinesApi::class)
    val allTransactions: StateFlow<List<TransactionEntity>> = userSession
        .flatMapLatest { session ->
            if (session.userId.isNotEmpty()) repository.getAllTransactions(session.userId)
            else flowOf(emptyList())
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val allWallets: StateFlow<List<WalletEntity>> = userSession
        .flatMapLatest { session ->
            if (session.userId.isNotEmpty()) repository.getAllWallets(session.userId)
            else flowOf(emptyList())
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val allPortfolios: StateFlow<List<PortfolioEntity>> = userSession
        .flatMapLatest { session ->
            if (session.userId.isNotEmpty()) repository.getAllPortfolios(session.userId)
            else flowOf(emptyList())
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val allSavingGoals: StateFlow<List<SavingGoalEntity>> = userSession
        .flatMapLatest { session ->
            if (session.userId.isNotEmpty()) repository.getAllSavingGoals(session.userId)
            else flowOf(emptyList())
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val allBudgets: StateFlow<List<BudgetEntity>> = userSession
        .flatMapLatest { session ->
            if (session.userId.isNotEmpty()) repository.getAllBudgets(session.userId)
            else flowOf(emptyList())
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val allNotes: StateFlow<List<FinancialNoteEntity>> = userSession
        .flatMapLatest { session ->
            if (session.userId.isNotEmpty()) repository.getAllNotes(session.userId)
            else flowOf(emptyList())
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val allRecurring: StateFlow<List<RecurringTransactionEntity>> = userSession
        .flatMapLatest { session ->
            if (session.userId.isNotEmpty()) repository.getAllRecurring(session.userId)
            else flowOf(emptyList())
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Computed Filtered Transactions
    private val filterParams = combine(
        selectedPeriod,
        transactionSearchQuery,
        selectedTypeFilter,
        selectedCategoryFilter,
        selectedWalletFilter
    ) { period, query, typeFilter, catFilter, walletFilter ->
        listOf(period, query, typeFilter, catFilter, walletFilter)
    }.combine(transactionSort) { list5, sort ->
        val period = list5[0] as TimePeriodFilter
        val query = list5[1] as String
        val typeFilter = list5[2] as? String
        val catFilter = list5[3] as? String
        val walletFilter = list5[4] as? Long
        object {
            val period = period
            val query = query
            val typeFilter = typeFilter
            val catFilter = catFilter
            val walletFilter = walletFilter
            val sort = sort
        }
    }

    val filteredTransactions: StateFlow<List<TransactionEntity>> = combine(
        allTransactions,
        filterParams
    ) { txList, params ->
        var list = txList

        // Period filter
        val now = Calendar.getInstance()
        when (params.period) {
            TimePeriodFilter.THIS_MONTH -> {
                val start = DateUtils.getStartOfMonth(now)
                val end = DateUtils.getEndOfMonth(now)
                list = list.filter { it.date in start..end }
            }
            TimePeriodFilter.THIS_WEEK -> {
                val start = DateUtils.getStartOfWeek(now)
                list = list.filter { it.date >= start }
            }
            TimePeriodFilter.THIS_YEAR -> {
                val start = DateUtils.getStartOfYear(now)
                list = list.filter { it.date >= start }
            }
            TimePeriodFilter.ALL_TIME, TimePeriodFilter.CUSTOM -> {
                // No time filter
            }
        }

        // Type filter
        if (params.typeFilter != null && params.typeFilter != "ALL") {
            list = list.filter { it.type == params.typeFilter }
        }

        // Category filter
        if (params.catFilter != null) {
            list = list.filter { it.categoryId == params.catFilter }
        }

        // Wallet filter
        if (params.walletFilter != null) {
            list = list.filter { it.walletId == params.walletFilter || it.targetWalletId == params.walletFilter }
        }

        // Search query
        if (params.query.isNotBlank()) {
            list = list.filter {
                it.note.contains(params.query, ignoreCase = true) ||
                it.categoryName.contains(params.query, ignoreCase = true) ||
                it.walletName.contains(params.query, ignoreCase = true) ||
                (it.targetWalletName?.contains(params.query, ignoreCase = true) == true)
            }
        }

        // Sorting
        when (params.sort) {
            TransactionSortOption.DATE_DESC -> list.sortedByDescending { it.date }
            TransactionSortOption.DATE_ASC -> list.sortedBy { it.date }
            TransactionSortOption.AMOUNT_DESC -> list.sortedByDescending { it.amount }
            TransactionSortOption.AMOUNT_ASC -> list.sortedBy { it.amount }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Dashboard State Computation
    val dashboardUiState: StateFlow<DashboardUiState> = combine(
        allTransactions,
        allWallets,
        allPortfolios,
        allSavingGoals,
        allBudgets
    ) { transactions, wallets, portfolios, savingGoals, budgets ->
        // Total Incomes and Expenses
        val totalIncome = transactions.filter { it.type == "INCOME" }.sumOf { it.amount }
        val totalExpense = transactions.filter { it.type == "EXPENSE" }.sumOf { it.amount }
        // Saldo = total pemasukan - total pengeluaran (Transfer does not affect net formula)
        val totalBalance = totalIncome - totalExpense

        val totalPortfolio = portfolios.sumOf { it.currentValue }
        val totalSavings = savingGoals.sumOf { it.currentAmount }

        // Category Spend Summary (for Donut Chart)
        val expenseTx = transactions.filter { it.type == "EXPENSE" }
        val catMap = expenseTx.groupBy { it.categoryId }
        val catSpendSummaries = catMap.map { (catId, txs) ->
            val total = txs.sumOf { it.amount }
            val first = txs.first()
            CategorySpendSummary(
                categoryId = catId,
                categoryName = first.categoryName,
                color = first.categoryColor,
                totalAmount = total,
                percentage = if (totalExpense > 0) ((total / totalExpense) * 100).toFloat() else 0f
            )
        }.sortedByDescending { it.totalAmount }

        // Monthly Bars (last 6 months)
        val monthlyBars = computeMonthlyBars(transactions)

        // Balance Trend Line
        val balanceTrend = computeBalanceTrend(transactions)

        // Active budget spend calculation
        val currentMonthStart = DateUtils.getStartOfMonth()
        val currentMonthEnd = DateUtils.getEndOfMonth()
        val monthExpenses = transactions.filter { it.type == "EXPENSE" && it.date in currentMonthStart..currentMonthEnd }
        
        val budgetProgressList = budgets.map { budget ->
            val spent = monthExpenses.filter { it.categoryId == budget.categoryId }.sumOf { it.amount }
            Pair(budget, spent)
        }

        DashboardUiState(
            totalBalance = totalBalance,
            totalIncome = totalIncome,
            totalExpense = totalExpense,
            totalSavings = totalSavings,
            totalPortfolio = totalPortfolio,
            recentTransactions = transactions.take(5),
            topExpenseCategories = catSpendSummaries,
            monthlyBars = monthlyBars,
            balanceTrend = balanceTrend,
            activeBudgets = budgetProgressList,
            activeSavingGoals = savingGoals.take(3)
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardUiState())

    // --- ACTIONS ---

    fun loginUser(userId: String, name: String, email: String, isGoogle: Boolean) {
        viewModelScope.launch {
            sessionManager.saveLoginSession(userId, name, email, isGoogleAuth = isGoogle)
            userMessage.value = "Selamat datang, $name!"
        }
    }

    fun logout() {
        viewModelScope.launch {
            sessionManager.clearSession()
            userMessage.value = "Berhasil keluar"
        }
    }

    fun deleteAccountAndData() {
        val currentUserId = userSession.value.userId
        viewModelScope.launch {
            if (currentUserId.isNotEmpty()) {
                repository.deleteAllUserData(currentUserId)
                sessionManager.clearSession()
                userMessage.value = "Akun dan semua data berhasil dihapus"
            }
        }
    }

    // Transactions CRUD
    fun addTransaction(
        type: String,
        amount: Double,
        categoryId: String,
        categoryName: String,
        categoryColor: Long,
        categoryIcon: String,
        walletId: Long,
        walletName: String,
        targetWalletId: Long? = null,
        targetWalletName: String? = null,
        adminFee: Double = 0.0,
        note: String = "",
        date: Long = System.currentTimeMillis()
    ) {
        val userId = userSession.value.userId
        if (userId.isEmpty() || amount <= 0) return
        viewModelScope.launch {
            if (type == "TRANSFER" && targetWalletId != null && targetWalletName != null) {
                repository.transferBetweenWallets(
                    userId = userId,
                    sourceWalletId = walletId,
                    sourceWalletName = walletName,
                    targetWalletId = targetWalletId,
                    targetWalletName = targetWalletName,
                    amount = amount,
                    adminFee = adminFee,
                    note = note,
                    date = date
                )
            } else {
                val entity = TransactionEntity(
                    userId = userId,
                    type = type,
                    amount = amount,
                    categoryId = categoryId,
                    categoryName = categoryName,
                    categoryColor = categoryColor,
                    categoryIcon = categoryIcon,
                    walletId = walletId,
                    walletName = walletName,
                    targetWalletId = targetWalletId,
                    targetWalletName = targetWalletName,
                    adminFee = adminFee,
                    note = note,
                    date = date
                )
                repository.insertTransaction(entity)
            }
            userMessage.value = "Transaksi berhasil disimpan"
        }
    }

    fun updateTransaction(transaction: TransactionEntity) {
        viewModelScope.launch {
            repository.updateTransaction(transaction)
            userMessage.value = "Transaksi diperbarui"
        }
    }

    fun deleteTransaction(transaction: TransactionEntity) {
        viewModelScope.launch {
            repository.deleteTransaction(transaction)
            userMessage.value = "Transaksi dihapus"
        }
    }

    fun deleteMultipleTransactions(ids: List<Long>) {
        val userId = userSession.value.userId
        if (userId.isEmpty() || ids.isEmpty()) return
        viewModelScope.launch {
            repository.deleteTransactionsByIds(userId, ids)
            userMessage.value = "${ids.size} transaksi dihapus"
        }
    }

    // Wallets CRUD
    fun addWallet(name: String, type: String, initialBalance: Double, color: Long, icon: String, accountNumber: String = "") {
        val userId = userSession.value.userId
        if (userId.isEmpty() || name.isBlank()) return
        viewModelScope.launch {
            val wallet = WalletEntity(
                userId = userId,
                name = name,
                type = type,
                initialBalance = initialBalance,
                currentBalance = initialBalance,
                accountNumber = accountNumber,
                color = color,
                icon = icon
            )
            val walletId = repository.insertWallet(wallet)
            // If initial balance > 0, record initial income transaction
            if (initialBalance > 0) {
                repository.insertTransaction(
                    TransactionEntity(
                        userId = userId,
                        type = "INCOME",
                        amount = initialBalance,
                        categoryId = "cat_salary",
                        categoryName = "Saldo Awal Dompet",
                        categoryColor = color,
                        categoryIcon = icon,
                        walletId = walletId,
                        walletName = name,
                        note = "Saldo awal saat pembuatan dompet $name"
                    )
                )
            }
            userMessage.value = "Dompet $name berhasil ditambahkan"
        }
    }

    fun updateWallet(wallet: WalletEntity) {
        viewModelScope.launch {
            repository.updateWallet(wallet)
            userMessage.value = "Dompet diperbarui"
        }
    }

    fun deleteWallet(wallet: WalletEntity) {
        viewModelScope.launch {
            repository.deleteWallet(wallet)
            userMessage.value = "Dompet dihapus"
        }
    }

    // Portfolios CRUD
    fun addPortfolio(name: String, type: String, currentValue: Double, initialInvested: Double, targetValue: Double, notes: String, color: Long, icon: String) {
        val userId = userSession.value.userId
        if (userId.isEmpty() || name.isBlank()) return
        viewModelScope.launch {
            val portfolio = PortfolioEntity(
                userId = userId,
                name = name,
                type = type,
                currentValue = currentValue,
                initialInvested = initialInvested,
                targetValue = targetValue,
                color = color,
                icon = icon,
                notes = notes
            )
            repository.insertPortfolio(portfolio)
            userMessage.value = "Portofolio $name berhasil disimpan"
        }
    }

    fun updatePortfolio(portfolio: PortfolioEntity) {
        viewModelScope.launch {
            repository.updatePortfolio(portfolio.copy(lastUpdated = System.currentTimeMillis()))
            userMessage.value = "Portofolio diperbarui"
        }
    }

    fun deletePortfolio(portfolio: PortfolioEntity) {
        viewModelScope.launch {
            repository.deletePortfolio(portfolio)
            userMessage.value = "Portofolio dihapus"
        }
    }

    // Saving Goals CRUD
    fun addSavingGoal(title: String, targetAmount: Double, targetDate: Long, color: Long, icon: String, notes: String) {
        val userId = userSession.value.userId
        if (userId.isEmpty() || title.isBlank() || targetAmount <= 0) return
        viewModelScope.launch {
            val goal = SavingGoalEntity(
                userId = userId,
                title = title,
                targetAmount = targetAmount,
                currentAmount = 0.0,
                targetDate = targetDate,
                color = color,
                icon = icon,
                notes = notes
            )
            repository.insertSavingGoal(goal)
            userMessage.value = "Target tabungan $title dibuat"
        }
    }

    fun addFundsToGoal(goalId: Long, amount: Double, walletId: Long, walletName: String, note: String) {
        val userId = userSession.value.userId
        if (userId.isEmpty() || amount <= 0) return
        viewModelScope.launch {
            repository.addFundsToSavingGoal(userId, goalId, amount, walletId, walletName, note)
            userMessage.value = "Berhasil menambah tabungan"
        }
    }

    fun updateSavingGoal(goal: SavingGoalEntity) {
        viewModelScope.launch {
            repository.updateSavingGoal(goal)
            userMessage.value = "Target tabungan diperbarui"
        }
    }

    fun deleteSavingGoal(goal: SavingGoalEntity) {
        viewModelScope.launch {
            repository.deleteSavingGoal(goal)
            userMessage.value = "Target tabungan dihapus"
        }
    }

    // Budgets CRUD
    fun addBudget(categoryId: String, categoryName: String, categoryColor: Long, limitAmount: Double, period: String) {
        val userId = userSession.value.userId
        if (userId.isEmpty() || limitAmount <= 0) return
        viewModelScope.launch {
            val budget = BudgetEntity(
                userId = userId,
                categoryId = categoryId,
                categoryName = categoryName,
                categoryColor = categoryColor,
                limitAmount = limitAmount,
                period = period
            )
            repository.insertBudget(budget)
            userMessage.value = "Anggaran $categoryName dibuat"
        }
    }

    fun updateBudget(budget: BudgetEntity) {
        viewModelScope.launch {
            repository.updateBudget(budget)
            userMessage.value = "Anggaran diperbarui"
        }
    }

    fun deleteBudget(budget: BudgetEntity) {
        viewModelScope.launch {
            repository.deleteBudget(budget)
            userMessage.value = "Anggaran dihapus"
        }
    }

    // Notes CRUD
    fun addNote(title: String, content: String, colorTag: Long) {
        val userId = userSession.value.userId
        if (userId.isEmpty() || title.isBlank()) return
        viewModelScope.launch {
            val note = FinancialNoteEntity(
                userId = userId,
                title = title,
                content = content,
                colorTag = colorTag
            )
            repository.insertNote(note)
            userMessage.value = "Catatan disimpan"
        }
    }

    fun updateNote(note: FinancialNoteEntity) {
        viewModelScope.launch {
            repository.updateNote(note.copy(updatedAt = System.currentTimeMillis()))
            userMessage.value = "Catatan diperbarui"
        }
    }

    fun togglePinNote(note: FinancialNoteEntity) {
        viewModelScope.launch {
            repository.updateNote(note.copy(isPinned = !note.isPinned, updatedAt = System.currentTimeMillis()))
        }
    }

    fun deleteNote(note: FinancialNoteEntity) {
        viewModelScope.launch {
            repository.deleteNote(note)
            userMessage.value = "Catatan dihapus"
        }
    }

    // Recurring Transactions CRUD
    fun addRecurring(title: String, type: String, amount: Double, categoryId: String, categoryName: String, walletId: Long, walletName: String, interval: String, nextDueDate: Long, note: String) {
        val userId = userSession.value.userId
        if (userId.isEmpty() || title.isBlank() || amount <= 0) return
        viewModelScope.launch {
            val recurring = RecurringTransactionEntity(
                userId = userId,
                title = title,
                type = type,
                amount = amount,
                categoryId = categoryId,
                categoryName = categoryName,
                walletId = walletId,
                walletName = walletName,
                interval = interval,
                nextDueDate = nextDueDate,
                note = note
            )
            repository.insertRecurring(recurring)
            userMessage.value = "Pengingat berulang $title berhasil dibuat"
        }
    }

    fun updateRecurring(recurring: RecurringTransactionEntity) {
        viewModelScope.launch {
            repository.updateRecurring(recurring)
            userMessage.value = "Pengingat diperbarui"
        }
    }

    fun deleteRecurring(recurring: RecurringTransactionEntity) {
        viewModelScope.launch {
            repository.deleteRecurring(recurring)
            userMessage.value = "Pengingat dihapus"
        }
    }

    // AI Assistant Generation
    fun triggerAiAnalysis(userQuestion: String = "") {
        viewModelScope.launch {
            aiState.value = aiState.value.copy(isLoading = true, errorMessage = "")
            val dash = dashboardUiState.value
            val topExp = dash.topExpenseCategories.map { Pair(it.categoryName, it.totalAmount) }
            
            try {
                val result = geminiService.analyzeFinancialHealth(
                    totalIncome = dash.totalIncome,
                    totalExpense = dash.totalExpense,
                    netBalance = dash.totalBalance,
                    portfolios = allPortfolios.value,
                    savingGoals = allSavingGoals.value,
                    budgets = allBudgets.value,
                    topExpenses = topExp,
                    userQuestion = userQuestion
                )
                aiState.value = AiAssistantUiState(
                    isLoading = false,
                    analysisText = result,
                    lastUpdated = System.currentTimeMillis()
                )
            } catch (e: Exception) {
                aiState.value = AiAssistantUiState(
                    isLoading = false,
                    errorMessage = "Gagal memproses AI: ${e.message}",
                    lastUpdated = System.currentTimeMillis()
                )
            }
        }
    }

    // Helper functions for chart computations
    private fun computeMonthlyBars(transactions: List<TransactionEntity>): List<MonthlyBarData> {
        val result = mutableListOf<MonthlyBarData>()
        val cal = Calendar.getInstance()
        
        for (i in 5 downTo 0) {
            val c = cal.clone() as Calendar
            c.add(Calendar.MONTH, -i)
            val monthStart = DateUtils.getStartOfMonth(c)
            val monthEnd = DateUtils.getEndOfMonth(c)
            val label = DateUtils.formatShortDate(monthStart)

            val inc = transactions.filter { it.type == "INCOME" && it.date in monthStart..monthEnd }.sumOf { it.amount }
            val exp = transactions.filter { it.type == "EXPENSE" && it.date in monthStart..monthEnd }.sumOf { it.amount }

            result.add(MonthlyBarData(monthLabel = label, income = inc, expense = exp))
        }
        return result
    }

    private fun computeBalanceTrend(transactions: List<TransactionEntity>): List<Pair<String, Double>> {
        if (transactions.isEmpty()) return emptyList()
        val sorted = transactions.sortedBy { it.date }
        val points = mutableListOf<Pair<String, Double>>()
        var runningBalance = 0.0

        for (tx in sorted) {
            if (tx.type == "INCOME") runningBalance += tx.amount
            else if (tx.type == "EXPENSE") runningBalance -= tx.amount
            points.add(Pair(DateUtils.formatShortDate(tx.date), runningBalance))
        }
        return if (points.size > 8) points.takeLast(8) else points
    }
}
