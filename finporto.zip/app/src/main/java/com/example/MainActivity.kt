package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.components.CalculatorDialog
import com.example.ui.components.PinLockScreen
import com.example.ui.screens.ai.AiAssistantScreen
import com.example.ui.screens.analytics.AnalyticsScreen
import com.example.ui.screens.auth.AuthScreen
import com.example.ui.screens.dashboard.DashboardScreen
import com.example.ui.screens.goals.BudgetGoalsScreen
import com.example.ui.screens.notes.NotesScreen
import com.example.ui.screens.portfolios.PortfoliosScreen
import com.example.ui.screens.recurring.RecurringScreen
import com.example.ui.screens.search.GlobalSearchScreen
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.screens.transactions.AddEditTransactionBottomSheet
import com.example.ui.screens.transactions.TransactionsScreen
import com.example.ui.screens.wallets.WalletsScreen
import com.example.ui.theme.*
import com.example.ui.viewmodel.FinPortoViewModel

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    object Dashboard : Screen("dashboard", "Beranda", Icons.Default.Dashboard)
    object Transactions : Screen("transactions", "Transaksi", Icons.Default.ReceiptLong)
    object Wallets : Screen("wallets", "Dompet", Icons.Default.AccountBalanceWallet)
    object Portfolios : Screen("portfolios", "Portofolio", Icons.Default.PieChart)
    object Settings : Screen("settings", "Menu", Icons.Default.GridView)

    // Sub-screens
    object Goals : Screen("goals", "Target & Budget", Icons.Default.Savings)
    object Analytics : Screen("analytics", "Statistik", Icons.Default.BarChart)
    object Notes : Screen("notes", "Catatan", Icons.Default.StickyNote2)
    object Recurring : Screen("recurring", "Tagihan", Icons.Default.EventRepeat)
    object AiAssistant : Screen("ai_assistant", "AI Asisten", Icons.Default.AutoAwesome)
    object GlobalSearch : Screen("search", "Cari", Icons.Default.Search)
}

class MainActivity : ComponentActivity() {
    private val viewModel: FinPortoViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            FinPortoTheme {
                FinPortoApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun FinPortoApp(viewModel: FinPortoViewModel) {
    val navController = rememberNavController()
    val userSession by viewModel.userSession.collectAsStateWithLifecycle()
    val userMessage by viewModel.userMessage.collectAsStateWithLifecycle()
    val wallets by viewModel.allWallets.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    var isUnlocked by remember { mutableStateOf(false) }
    var showGlobalCalcDialog by remember { mutableStateOf(false) }
    var showGlobalAddTxSheet by remember { mutableStateOf(false) }

    LaunchedEffect(userMessage) {
        userMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.userMessage.value = null
        }
    }

    // Authentication & PIN Lock Gate
    if (!userSession.isLoggedIn) {
        AuthScreen(
            viewModel = viewModel,
            onLoginSuccess = { isUnlocked = true }
        )
        return
    }

    if (userSession.isPinEnabled && !isUnlocked) {
        PinLockScreen(
            correctPin = userSession.pinCode,
            isBiometricAvailable = userSession.isBiometricEnabled,
            onSuccess = { isUnlocked = true },
            onBiometricClick = { isUnlocked = true }
        )
        return
    }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    // Optimal 5-Item Bottom Navigation Bar (Material 3 Standard)
    val bottomNavItems = listOf(
        Screen.Dashboard,
        Screen.Transactions,
        Screen.Wallets,
        Screen.Portfolios,
        Screen.Settings
    )

    val showBottomBar = currentRoute in bottomNavItems.map { it.route }

    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(
                    containerColor = PolishNavBg,
                    tonalElevation = 0.dp
                ) {
                    bottomNavItems.forEach { screen ->
                        val isSelected = currentRoute == screen.route
                        NavigationBarItem(
                            icon = { Icon(screen.icon, contentDescription = screen.title) },
                            label = {
                                Text(
                                    text = screen.title,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            },
                            selected = isSelected,
                            onClick = {
                                if (currentRoute != screen.route) {
                                    navController.navigate(screen.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = OnBlueContainer,
                                selectedTextColor = OnBlueContainer,
                                indicatorColor = BlueContainer,
                                unselectedIconColor = PolishTextMuted,
                                unselectedTextColor = PolishTextMuted
                            ),
                            modifier = Modifier.testTag("nav_item_${screen.route}")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Dashboard.route,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // 1. Dashboard / Beranda
            composable(Screen.Dashboard.route) {
                DashboardScreen(
                    viewModel = viewModel,
                    onNavigateToTransactions = { navController.navigate(Screen.Transactions.route) },
                    onNavigateToWallets = { navController.navigate(Screen.Wallets.route) },
                    onNavigateToPortfolios = { navController.navigate(Screen.Portfolios.route) },
                    onNavigateToGoals = { navController.navigate(Screen.Goals.route) },
                    onNavigateToAi = { navController.navigate(Screen.AiAssistant.route) },
                    onOpenCalculator = { showGlobalCalcDialog = true },
                    onAddTransactionClick = { showGlobalAddTxSheet = true },
                    onSearchClick = { navController.navigate(Screen.GlobalSearch.route) }
                )
            }

            // 2. Transaksi
            composable(Screen.Transactions.route) {
                TransactionsScreen(
                    viewModel = viewModel,
                    onOpenCalculator = { showGlobalCalcDialog = true }
                )
            }

            // 3. Dompet & Rekening
            composable(Screen.Wallets.route) {
                WalletsScreen(viewModel = viewModel)
            }

            // 4. Portofolio & Aset
            composable(Screen.Portfolios.route) {
                PortfoliosScreen(viewModel = viewModel)
            }

            // 5. Hub Menu & Pengaturan
            composable(Screen.Settings.route) {
                SettingsScreen(
                    viewModel = viewModel,
                    onNavigateToGoals = { navController.navigate(Screen.Goals.route) },
                    onNavigateToAnalytics = { navController.navigate(Screen.Analytics.route) },
                    onNavigateToRecurring = { navController.navigate(Screen.Recurring.route) },
                    onNavigateToNotes = { navController.navigate(Screen.Notes.route) },
                    onNavigateToAi = { navController.navigate(Screen.AiAssistant.route) },
                    onOpenCalculator = { showGlobalCalcDialog = true },
                    onLogout = { isUnlocked = false }
                )
            }

            // Sub-destinations
            composable(Screen.Goals.route) {
                BudgetGoalsScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Screen.Analytics.route) {
                AnalyticsScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Screen.Notes.route) {
                NotesScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Screen.Recurring.route) {
                RecurringScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Screen.AiAssistant.route) {
                AiAssistantScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Screen.GlobalSearch.route) {
                GlobalSearchScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }

    // Global Calculator Dialog
    if (showGlobalCalcDialog) {
        CalculatorDialog(
            initialValue = 0.0,
            onDismiss = { showGlobalCalcDialog = false },
            onApplyAmount = { showGlobalCalcDialog = false }
        )
    }

    // Global Add Transaction Bottom Sheet
    if (showGlobalAddTxSheet) {
        AddEditTransactionBottomSheet(
            transactionToEdit = null,
            wallets = wallets,
            onDismiss = { showGlobalAddTxSheet = false },
            onSave = { type, amount, catId, catName, catColor, catIcon, walletId, walletName, targetWId, targetWName, adminFee, note, date ->
                viewModel.addTransaction(
                    type = type,
                    amount = amount,
                    categoryId = catId,
                    categoryName = catName,
                    categoryColor = catColor,
                    categoryIcon = catIcon,
                    walletId = walletId,
                    walletName = walletName,
                    targetWalletId = targetWId,
                    targetWalletName = targetWName,
                    adminFee = adminFee,
                    note = note,
                    date = date
                )
                showGlobalAddTxSheet = false
            }
        )
    }
}
